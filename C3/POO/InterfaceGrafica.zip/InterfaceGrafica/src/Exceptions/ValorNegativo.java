
package Exceptions;

/**
 *
 * @author Thiiago
 */

public class ValorNegativo extends Exception {
    
    public ValorNegativo() {}
    
    public ValorNegativo(String msg) {
        super(msg);
    }
}
