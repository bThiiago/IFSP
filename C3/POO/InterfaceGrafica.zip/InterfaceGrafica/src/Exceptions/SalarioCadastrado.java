
package Exceptions;

/**
 *
 * @author Thiiago
 */

public class SalarioCadastrado extends Exception {
    
    public SalarioCadastrado() {}
    
    public SalarioCadastrado(String msg) {
        super(msg);
    }
}
