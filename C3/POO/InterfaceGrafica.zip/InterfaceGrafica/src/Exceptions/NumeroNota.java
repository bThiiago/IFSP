
package Exceptions;

/**
 *
 * @author Thiiago
 */

public class NumeroNota extends Exception {
    
    public NumeroNota() {}
    
    public NumeroNota(String msg) {
        super(msg);
    }
}
