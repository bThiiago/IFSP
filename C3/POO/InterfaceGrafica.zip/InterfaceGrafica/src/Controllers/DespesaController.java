
package Controllers;

import Exceptions.ValorNegativo;
import Models.Despesa;
import java.text.ParseException;
import java.util.ArrayList;

/**
 *
 * @author Thiiago
 */

public class DespesaController {
    ArrayList<Despesa> despesas = new ArrayList<>();
    
    public DespesaController(){}

    public void readDespesa() throws ParseException {
        Despesa d = new Despesa();
        d.readDespesa();
    }

    public void showDespesa() {
        for (Despesa d : despesas) {
            d.showDespesa();
        }
    }
    
    public ArrayList<Despesa> getDespesas() {
        return this.despesas;
    }
    
    public void addDespesa(Despesa d) throws ValorNegativo {
        if (d.getValor() <= 0){
            throw new ValorNegativo("O valor inserido é inválido.");
        } else {
            this.despesas.add(d);
        }
    }

    public void delDespesa(Despesa d) {
        int i = 0, posicao = -1;

        for (Despesa desp : despesas) {
            if (desp.getCodigo() == d.getCodigo()) {
                posicao = i;
            }
            i++;
        }

        if (posicao != -1) {
            this.despesas.remove(posicao);
        }
    }
    
    public double somaSalario() {
        double s = 0;

        for (Despesa d : despesas) {
            s += d.getValorMovimento();
        }

        return s;
    }
}
