
package Controllers;

import Exceptions.SalarioCadastrado;
import Models.Salario;
import java.text.ParseException;
import java.util.ArrayList;

/**
 *
 * @author Thiiago
 */

public class SalarioController {
    private static ArrayList<Salario> salarios = new ArrayList<>();
    
    public SalarioController(){}

    public void readSalario() throws ParseException {
        Salario s = new Salario();
        s.readSalario();
        this.salarios.add(s);
    }

    public void showSalario() {
        for (Salario d : salarios) {
            d.showSalario();
        }
    }
    
    public ArrayList<Salario> getSalarios() {
        return this.salarios;
    }
    
    public double somaSalario() {
        double so = 0;

        for (Salario s : salarios) {
            so += s.getValorMovimento();
        }

        return so;
    }
    
     public void addSalario(Salario s) throws SalarioCadastrado {
        for (Salario sal : SalarioController.salarios) {
            if (sal.getPront() == s.getPront()) {
                throw new SalarioCadastrado("Um salario com o prontuario " + sal.getPront() + " ja foi cadastrado.");
            } else if (sal.getMes().equals(s.getMes())) {
                throw new SalarioCadastrado("Um salario com o mes/ano " + sal.getMes() + " ja foi cadastrado.");
            }
        }

        this.salarios.add(s);
    }
    
    public void delSalario(Salario s) {
        int i = 0, posicao = -1;

        for (Salario sal : salarios) {
            if (sal.getPront() == s.getPront()) {
                posicao = i;
            }
            i++;
        }

        if (posicao != -1) {
            this.salarios.remove(posicao);
        }
    }
}
