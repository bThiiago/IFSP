
package Controllers;

import Models.Movimento;
import java.util.ArrayList;

/**
 *
 * @author Thiiago
 */

public class MovimentoController {
    ArrayList<Movimento> movimentos = new ArrayList<>();

    private DespesaController despesas;
    private SalarioController salarios;
    private VendaController vendas;

    public MovimentoController(DespesaController despesas, SalarioController salarios, VendaController vendas) {
        this.despesas = despesas;
        this.salarios = salarios;
        this.vendas = vendas;
    }

    public ArrayList<Movimento> getListamovimento() {

        ArrayList<Movimento> listamovimento = new ArrayList<>();

        listamovimento.addAll(this.despesas.getDespesas());
        listamovimento.addAll(this.salarios.getSalarios());
        listamovimento.addAll(this.vendas.getVendas());

        return listamovimento;
    }

    public double total() {
        double total = this.salarios.somaSalario() + this.despesas.somaSalario() + this.vendas.somaSalario();
        return total;
    }
    
    public DespesaController getControledespesas() {
        return despesas;
    }

    public void setControledespesas(DespesaController controledespesas) {
        this.despesas = controledespesas;
    }

    public VendaController getControlevenda() {
        return vendas;
    }

    public void setControlevenda(VendaController controlevenda) {
        this.vendas = controlevenda;
    }

    public SalarioController getControlasalario() {
        return salarios;
    }

    public void setControlasalario(SalarioController controlasalario) {
        this.salarios = controlasalario;
    }
}
