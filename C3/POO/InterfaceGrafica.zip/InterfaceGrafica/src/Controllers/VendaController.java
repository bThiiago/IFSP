
package Controllers;

import Exceptions.NumeroNota;
import Models.Venda;
import java.text.ParseException;
import java.util.ArrayList;

/**
 *
 * @author Thiiago
 */

public class VendaController {
    private static ArrayList<Venda> vendas = new ArrayList<>();
    
    public VendaController(){}

    public void readVenda() throws ParseException {
        Venda v = new Venda();
        v.readVenda();
        this.vendas.add(v);
    }

    public void showVenda() {
        for (Venda d : vendas) {
            d.showVenda();
        }
    }
    
    public ArrayList<Venda> getVendas() {
        return this.vendas;
    }
    
    public double somaSalario() {
        double s = 0;

        for (Venda v : vendas) {
            s += v.getValorMovimento();
        }

        return s;
    }
    
    public void addVenda(Venda v) throws Exception {

        for (Venda vend : VendaController.vendas) {
            if (vend.getNota() == v.getNota()) {
                throw new NumeroNota("A venda " + vend.getNota() + " ja foi cadastrada.");
            }
        }

        this.vendas.add(v);
    }

    public void excluir(Venda v) {

        int i = 0;
        int posicao = -1;

        for (Venda vend : vendas) {

            if (vend.getNota() == v.getNota()) {
                posicao = i;
            }

            i++;
        }

        if (posicao != -1) {
            this.vendas.remove(posicao);
        }

    }
}
