
package Models;

/**
 *
 * @author Thiiago
 */

public interface Movimento {
    public String getMovimento();
    public double getValorMovimento();
}
