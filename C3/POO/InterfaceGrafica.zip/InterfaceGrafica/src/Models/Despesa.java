
package Models;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author Thiiago
 */

public class Despesa implements Movimento {
    private int codigo;
    private String descricao;
    private double valor;
    private String data;
    
    public Despesa(){}
    
    public Despesa(int codigo, String descricao, double valor, String data){
        this.codigo = codigo;
        this.descricao = descricao;
        this.valor = valor;
        this.data = data;
    }
    
    public void readDespesa() throws ParseException {
        Scanner read = new Scanner(System.in);
        SimpleDateFormat form = new SimpleDateFormat("dd/MM/yyyy");
        Date date = form.parse(data);

        System.out.print("Digite o codigo da despesa......: ");
        this.codigo = read.nextInt(); read.nextLine();

        System.out.print("Digite a descricao da despesa...: ");
        this.descricao = read.nextLine();
        
        System.out.print("Digite o valor da despesa.......: ");
        this.valor = read.nextDouble(); read.nextLine();

        System.out.print("Digite a data da despesa........: ");
        this.data = read.nextLine();
    }
    
    public void showDespesa() {
        System.out.println("" + this.getMovimento());
    }
    
    public int getCodigo(){
        return codigo;
    }
    
    public void setCodigo(int codigo){
        this.codigo = codigo;
    }
    
    public String getDescricao(){
        return descricao;
    }
    
    public void setDescricao(String descricao){
        this.descricao = descricao;
    }
    
    public double getValor(){
        return valor;
    }
    
    public void setValor(double valor){
        this.valor = valor;
    }
    
    public String getData(){
        return data;
    }
    
    public void setData(String data){
        this.data = data;
    }
    
    @Override
    public String getMovimento(){
        return "Despesa...: " + this.data + " - " + this.descricao + " - R$" + this.valor;
    }
    
    @Override
    public double getValorMovimento(){
        return this.valor;
    }
}
