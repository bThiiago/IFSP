
package Models;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Thiiago
 */
public class Orcamento {
    private int nrOrc;
    private String defeito;
    private String diagnostico;
    private int qntParc;
    
    private Cliente cliente;
    private Aparelho aparelho;
    private Servico servico;
    private Peca peca;

    ArrayList<Peca> listaPecas = new ArrayList<>();
    ArrayList<Cliente> listaClientes = new ArrayList<>();
    ArrayList<Aparelho> listaAparelhos = new ArrayList<>();
    
    private ArrayList<Servico> listaServicos = new ArrayList<>();
    
    public Orcamento(){}
    
    public Orcamento(int nrOrc, String defeito, String diagnostico, int qntParc, Cliente cliente, Servico servico){
        this.nrOrc = nrOrc;
        this.defeito = defeito;
        this.diagnostico = diagnostico;
        this.qntParc = qntParc;
        this.cliente = cliente;
        this.servico = servico;
    }
    
    public Cliente getCliente(){
        return cliente;
    }
    
    public void setCliente(Cliente cliente){
        this.cliente = cliente;
    }
    
    public Aparelho getAparelho(){
        return aparelho;
    }
    
    public void setAparelho(Aparelho aparelho){
        this.aparelho = aparelho;
    }
    
    public Peca getPeca(){
        return peca;
    }
    
    public void setPeca(Peca peca){
        this.peca = peca;
    }
    
    public int getNumOrcamento(){
        return nrOrc;
    }
    
    public void setNumOrcamento(int nrOrc){
        this.nrOrc = nrOrc;
    }
    
    public String getDefeito(){
        return defeito;
    }
    
    public void setDefeito(String defeito){
        this.defeito = defeito;
    }
    
    public String getDiagnostico(){
        return diagnostico;
    }
    
    public void setDiagnostico(String diagnostico){
        this.diagnostico = diagnostico;
    }
    
    public int getParcelamento(){
        return qntParc;
    }
    
    public void setParcelamento(int qntParc){
        this.qntParc = qntParc;
    }
    
    public void addPeca(int codigo, String nome, double valorCusto, double valorVenda) {
        Peca p = new Peca(codigo, nome, valorCusto, valorVenda);
        p.readPeca();
        this.listaPecas.add(p);

    }
    
    public void addServico(String descricao, double valor){
        Servico s = new Servico(descricao, valor);
        s.readServico();
        this.listaServicos.add(s);
    }
    
    public List<Servico> getListaServicos(){
        return this.listaServicos;
    }
    
    public void readOrcamento() {
        Scanner read = new Scanner(System.in);

        System.out.print("\nDigite o numero do orcamento......: ");
        this.nrOrc = read.nextInt(); read.nextLine();
        
        System.out.print("Digite o defeito..................: ");
        this.defeito = read.nextLine();

        System.out.print("Digite o diagnostico..............: ");
        this.diagnostico = read.nextLine();

        System.out.print("Digite a quantidade de parcelas...: ");
        this.qntParc = read.nextInt();

    }
    
    public void showOrcamento() {
        System.out.println("\nNumero do orcamento......: " + this.nrOrc);
        System.out.println("Defeito do aparelho......: " + this.defeito);
        System.out.println("Diagnostico..............: " + this.diagnostico);
        System.out.println("Quantidade de Parcelas...: " + this.qntParc + "\n");
        
        for (Cliente c : listaClientes) {
        System.out.println("\nID do cliente......: " + c.getClienteID());
        System.out.println("Nome do cliente......: " + c.getNome());
        System.out.println("Email do cliente.....: " + c.getEmail());
        System.out.println("Numero de telefone...: " + c.getTelefone());
        }
        
        for (Aparelho a : listaAparelhos) {
            System.out.println("Codigo do aparelho.......: " + a.getAparelhoID());
            System.out.println("Modelo do aparelho.......: " + a.getModelo());
            System.out.println("Cor do aparelho..........: " + a.getCor());
        }

        for (Servico s : listaServicos) {
            System.out.println("Descricao do servico.....: " + s.getDescricao());
            System.out.println("Valor do servico.........: " + s.getValor());
        }

        for (Peca p : listaPecas) {
            System.out.println("Codigo da peca...........: " + p.getCodigo());
            System.out.println("Nome da peca.............: " + p.getNome());
            System.out.println("Valor de custo...........: " + p.getCusto());
            System.out.println("Valor de venda...........: " + p.getVenda());
        }
        
        System.out.println("\nValor total dos servicos...: " + this.totalServico());
        System.out.println("Valor total das pecas......: " + this.totalPecasVendas());
        System.out.println("Custo das pecas............: " + this.totalPecasCusto());
        System.out.println("Valor total do orcamento...: " + this.totalOrcamento());
        System.out.printf("Forma de pagamento: %d x %.2f.\n", this.qntParc, this.formadePagamento());
    }
    
    public void showOrcamento2() {
        System.out.println("\nNumero do orcamento...: " + this.nrOrc);
        for (Cliente c : listaClientes) {
            System.out.println("Nome do cliente.......: " + c.getNome());
        }
        for (Aparelho a : listaAparelhos) {
            System.out.println("Modelo do aparelho....: " + a.getModelo());
            System.out.println("Cor do aparelho.......: " + a.getCor());
        }
        for (Servico s : listaServicos) {
            System.out.println("Valor do servico......: " + s.getValor());
        }
    }
        
    public double totalServico() {
        double total = 0;

        for (Servico s : listaServicos) {
            total = total + s.getValor();
        }

        return total;
    }

    public double totalPecasVendas() {
        double total = 0;

        for (Peca p : listaPecas) {
            total = total + p.getVenda();
        }

        return total;
    }

    public double totalPecasCusto() {
        double total = 0;

        for (Peca p : listaPecas) {

            total = total + p.getVenda();
        }

        return total;
    }

    public double totalOrcamento() {
        double total = 0;

        total = totalServico() + totalPecasVendas();

        return total;
    }

    public double formadePagamento() {
        double parcela;

        parcela = totalOrcamento() / this.qntParc;

        return parcela;
    }
    
    @Override
    public int hashCode() {
        int hash = 5;
        hash = 17 * hash + this.nrOrc;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Orcamento other = (Orcamento) obj;
        if (this.nrOrc != other.nrOrc) {
            return false;
        }
        return true;
    }
}
