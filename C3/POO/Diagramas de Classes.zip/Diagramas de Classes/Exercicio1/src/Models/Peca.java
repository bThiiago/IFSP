
package Models;

import java.util.Scanner;

/**
 *
 * @author Thiiago
 */

public class Peca {
    private int codigo;
    private String nome;
    private double valorCusto;
    private double valorVenda;
    
    public Peca(){}
    
    public Peca(int codigo, String nome, double valorCusto, double valorVenda){
        this.codigo = codigo;
        this.nome = nome;
        this.valorCusto = valorCusto;
        this.valorVenda = valorVenda;
    }
    
    public void readPeca() {
        Scanner read = new Scanner(System.in);

        System.out.print("\nDigite o codigo da peca...: ");
        this.codigo = read.nextInt(); read.nextLine();
        
        System.out.print("Digite o nome da peca.....: ");
        this.nome = read.nextLine();

        System.out.print("Digite o valor de custo...: ");
        this.valorCusto = read.nextDouble();

        System.out.print("Digite o valor de venda...: ");
        this.valorVenda = read.nextDouble();

    }

    public void showPeca() {
        System.out.println("\nCodigo da peca...: " + this.codigo);
        System.out.println("Nome da peca.....: " + this.nome);
        System.out.println("Valor de custo...: " + this.valorCusto);
        System.out.println("Valor de venda...: " + this.valorVenda);
    }
    
    public int getCodigo(){
        return codigo;
    }
    
    public void setCodigo(int codigo){
        this.codigo = codigo;
    }
    
    public String getNome(){
        return nome;
    }
    
    public void setNome(String nome){
        this.nome = nome;
    }
    
    public double getCusto(){
        return valorCusto;
    }
    
    public void setCusto(double valorCusto){
        this.valorCusto = valorCusto;
    }
    
    public double getVenda(){
        return valorVenda;
    }
    
    public void setVenda(double valorVenda){
        this.valorVenda = valorVenda;
    }
    
}
