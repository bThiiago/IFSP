
package Models;

import java.util.Scanner;

/**
 *
 * @author Thiiago
 */

public class Aparelho {
    private int codigo;
    private String marca;
    private String modelo;
    private String cor;
    private String numero;
    
    public Aparelho(){}
    
    public Aparelho(int codigo, String numero, String marca, String modelo, String cor){
        this.marca = marca;
        this.modelo = modelo;
        this.cor = cor;
        this.numero = numero;
        this.codigo = codigo;
    }
    
     public void readAparelho() {
        Scanner read = new Scanner(System.in);

        System.out.print("\nDigite o codigo do aparelho...: ");
        this.codigo = read.nextInt();

        System.out.print("Digite o numero do telefone...: ");
        this.numero = read.nextLine();
        
        System.out.print("Digite a marca do Aparelho....: ");
        this.marca = read.nextLine();

        System.out.print("Digite a cor do Aparelho......: ");
        this.cor = read.nextLine();

        System.out.print("Digite o modelo do Aparelho...: ");
        this.modelo = read.nextLine();
    }
    
    public void showAparelho() {
        System.out.println("\nNumero de telefone...: " + this.numero);
        System.out.println("Marca do aparelho....: " + this.marca);
        System.out.println("Modelo do aparelho...: " + this.modelo);
        System.out.println("Cor do aparelho......: " + this.cor);
    }
    
    public int getAparelhoID() {

        return codigo;
    }
    
    public String getMarca(){
        return marca;
    }
    
    public void setMarca(String marca){
        this.marca = marca;
    }
    
    public String getModelo(){
        return modelo;
    }
    
    public void setModelo(String modelo){
        this.modelo = modelo;
    }
    
    public String getCor(){
        return cor;
    }
    
    public void setCor(String cor){
        this.cor = cor;
    }
    
    public String getNumero(){
        return numero;
    }
    
    public void setNumero(String numero){
        this.numero = numero;
    }
    
}
