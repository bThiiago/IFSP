
package Models;

import java.util.Scanner;

/**
 *
 * @author Thiiago
 */

public class Cliente {
    private int codigo;
    private String nome;
    private String telefone;
    private String email;
    
    public Cliente(){}
    
    public Cliente(int codigo, String nome, String telefone, String email){
        this.codigo = codigo;
        this.nome = nome;
        this.telefone = telefone;
        this.email = email;
    }
    
    public void readCliente() {
        Scanner read = new Scanner(System.in);

        System.out.print("\nDigite o ID do cliente.........: ");
        this.codigo = read.nextInt(); read.nextLine();
        
        System.out.print("Informe o nome.................: ");
        this.nome = read.nextLine();

        System.out.print("Informe o email................: ");
        this.email = read.nextLine();

        System.out.print("Informe o numero de telefone...: ");
        this.telefone = read.nextLine();
    }

    public void showCliente() {
        System.out.println("\nID do cliente......: " + this.codigo);
        System.out.println("Nome do cliente......: " + this.nome);
        System.out.println("Email do cliente.....: " + this.email);
        System.out.println("Numero de telefone...: " + this.telefone);
    }
    
    public int getClienteID() {
        return codigo;
    }

    public void setClienteID(int codigo) {
        this.codigo = codigo;
    }
    
    public String getNome(){
        return nome;
    }
    
    public void setNome(String nome){
        this.nome = nome;
    }
    
    public String getTelefone(){
        return telefone;
    }
    
    public void setTelefone(String telefone){
        this.telefone = telefone;
    }
    
    public String getEmail(){
        return email;
    }
    
    public void setEmail(String email){
        this.email = email;
    }
}
