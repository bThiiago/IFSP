
package Models;

import java.util.Scanner;

/**
 *
 * @author Thiiago
 */

public class Servico {
    private String descricao;
    private double valor;
    
    public Servico(){}
    
    public Servico(String descricao, double valor){
        this.descricao = descricao;
        this.valor = valor;
    }
    
    Servico(double total) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void readServico() {
        Scanner read = new Scanner(System.in);

        System.out.print("Digite a descricao do servico...: ");
        this.descricao = read.nextLine();

        System.out.print("Digite o valor do servico.......: ");
        this.valor = read.nextDouble();

    }

    public void showServicos() {

        System.out.println("Descricao do servico.....: " + this.descricao);
        System.out.println("Valor do servico.........: " + this.valor);
    }

    public double totalServico() {
        double total = 0;

        total = total + valor;

        return total;
    }
    
    public String getDescricao(){
        return descricao;
    }
    
    public void setDescricao(String descricao){
        this.descricao = descricao;
    }
    
    public double getValor(){
        return valor;
    }
    
    public void setValor(double valor){
        this.valor = valor;
    }
    
}
