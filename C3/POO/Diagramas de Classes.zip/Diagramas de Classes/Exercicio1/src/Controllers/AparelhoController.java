
package Controllers;

import Models.Aparelho;
import java.util.ArrayList;

/**
 *
 * @author Thiiago
 */

public class AparelhoController {
    
    ArrayList<Aparelho> aparelhos = new ArrayList<>();

    public void readAparelho() {
        Aparelho a = new Aparelho();
        a.readAparelho();
        aparelhos.add(a);
    }
    
    public Aparelho getAparelhoID(int codigo) {
        for (Aparelho a : aparelhos) {
            if (a.getAparelhoID() == codigo) {
                return a;
            }
        }
        return null;
    }

    public void showAparelhos() {
        for (Aparelho a : aparelhos) {
            a.showAparelho();
        }
    }

    public ArrayList<Aparelho> getAparelhos() {
        return aparelhos;
    }
}
