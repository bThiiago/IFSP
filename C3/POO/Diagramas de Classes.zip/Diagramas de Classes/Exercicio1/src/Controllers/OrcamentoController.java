
package Controllers;

import Models.Orcamento;
import Models.Cliente;
import Models.Aparelho;
import Models.Servico;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Thiiago
 */
public class OrcamentoController {
    private final ArrayList<Orcamento> orcamentos = new ArrayList<>();
    
    private ClienteController cController;
    private AparelhoController aController;
    
    public OrcamentoController(){}
    
    public OrcamentoController(ClienteController cController, AparelhoController aController){
        this.cController = cController;
        this.aController = aController;
    }
    
    public void readOrcamento() {
        int codigoC, codigoA;
        int codigoP = 0;
        double valor = 0;
        double valorc = 0, valorv = 0;
        String desc = null;
        String op;

        Cliente c;
        Aparelho a;
        Servico s = null;

        Scanner read = new Scanner(System.in);

        Orcamento o = new Orcamento();

        o.readOrcamento();
        System.out.print("Digite o ID do cliente............:  ");
        codigoC = read.nextInt();
        c = this.cController.getClientID(codigoC);
        o.setCliente(c);

        System.out.print("Digite o ID do Aparelho...........: ");
        codigoA = read.nextInt();
        a = this.aController.getAparelhoID(codigoA);
        o.setAparelho(a);

        o.addServico(desc, valor);

        do{

            System.out.print("Deseja cadastrar uma peca? (s/n): ");
            op = read.nextLine();

            if ("s".equals(op)) {
                o.addPeca(codigoP, op, valorc, valorv);
            }

        }while (!"n".equals(op));

        this.orcamentos.add(o);
    }
    
    public void searchByCode(){
        Scanner read = new Scanner(System.in);
        int codigo;
        
        System.out.println("Apresentar orcamento por código.");
        System.out.print("Informe o codigo: ");
        codigo = read.nextInt();read.nextLine();
        
        this.orcamentos.forEach(o -> {
            if (o.getNumOrcamento() == codigo) {
                o.showOrcamento();
            }
        });
    }
    
    public void show(){
        System.out.println("\nLista de orcamentos: ");
        
        this.orcamentos.forEach(o -> {
            o.showOrcamento2();
        });
    }
    
    public void exclude(){
        Scanner read = new Scanner(System.in);
        int codigo;
        
        System.out.println("Informe o codigo: ");
        codigo = read.nextInt();
        
        this.orcamentos.forEach(o -> {
            if (o.getNumOrcamento() == codigo) {
                System.out.println("Excluindo um orcamento...");
                orcamentos.remove(o);
            }
        });
    }
    
    public ArrayList<Orcamento> getOrcamentos() {
        return this.orcamentos;
    }
}

