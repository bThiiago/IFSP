
package Controllers;

import Models.Peca;
import java.util.ArrayList;

/**
 *
 * @author Thiiago
 */

public class PecaController {
    
    private ArrayList<Peca> pecas = new ArrayList<>();

    public void readPecas() {

        Peca p = new Peca();
        p.readPeca();
        this.pecas.add(p);

    }

    public void showPecas() {
        for (Peca p : pecas) {

            p.showPeca();
        }
    }
    
    public ArrayList<Peca> getPecas() {
        return this.pecas;
    }
}
