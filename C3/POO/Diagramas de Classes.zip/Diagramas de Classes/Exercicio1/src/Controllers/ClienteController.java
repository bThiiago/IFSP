
package Controllers;

import Models.Cliente;
import java.util.ArrayList;

/**
 *
 * @author Thiiago
 */

public class ClienteController {
    
    private ArrayList<Cliente> clientes = new ArrayList<>();
    
    public ClienteController(){}

    public void readCliente() {
        Cliente c = new Cliente();
        c.readCliente();
        this.clientes.add(c);
    }

    public void showClientes() {
        for (Cliente c : clientes) {
            c.showCliente();
        }
    }
    
    public Cliente getClientID(int codigo) {
        for (Cliente c : clientes) {
            if (c.getClienteID() == codigo) {
                return c;
            }
        }
        return null;
    }
    
    public ArrayList<Cliente> getClientes() {
        return this.clientes;
    }
}
