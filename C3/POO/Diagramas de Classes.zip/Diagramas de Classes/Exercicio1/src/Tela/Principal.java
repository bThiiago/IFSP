
package Tela;

import Controllers.AparelhoController;
import Controllers.ClienteController;
import Controllers.OrcamentoController;
import java.util.Scanner;

/**
 *
 * @author Thiiago
 */

public class Principal {
    
    public static void main(String[] args) {
        
    Scanner read = new Scanner(System.in);
    
    ClienteController cc = new ClienteController();
    AparelhoController ac = new AparelhoController();
    OrcamentoController oc = new OrcamentoController(cc, ac);

    int op;

        do {
            System.out.println("\n1 - Cadastrar clientes");
            System.out.println("2 - Cadastrar orcamentos");
            System.out.println("3 - Cadastrar aparelhos");
            System.out.println("4 - Apresentar um orcamento");
            System.out.println("5 - Listar todos os orcamentos");
            System.out.println("6 - Excluir um orcamento");
            System.out.println("0 - Sair do programa");
            System.out.print("\nInforme a opcao...: ");
            op = read.nextInt();

            switch (op) {
                case 1:
                    cc.readCliente();
                    break;
                case 2:
                    oc.readOrcamento();
                    break;
                case 3:
                    ac.readAparelho();
                    break;
                case 4:
                    oc.searchByCode();
                    break;
                case 5:
                    oc.show();
                    break;
                case 6:
                    oc.exclude();
                    break;

            }
        } while (op != 0);
    }
}
