
package Controllers;

import Models.Telefone;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Thiiago
 */

public class TelefoneController {
    private final ArrayList<Telefone> telefones = new ArrayList<>();
    
    public void add(){
        Telefone t = new Telefone();
        t.readTelefone();
        telefones.add(t);
    }
    
    public void addAccount(){
        Telefone t = new Telefone();
        
        int ano, mes; 
        float total;
        String vencimento;
        float valorMinuto;
        
        Scanner read = new Scanner(System.in);

        System.out.print("\nAno............: ");
        ano = read.nextInt();read.nextLine();
        System.out.print("Mes............: ");
        mes = read.nextInt();read.nextLine();
        System.out.print("Total..........: ");
        total = read.nextFloat();read.nextLine();
        System.out.print("Vencimento.....: ");
        vencimento = read.nextLine();
        System.out.print("Valor Minuto...: ");
        valorMinuto = read.nextFloat();read.nextLine();
        
        t.Conta(ano, mes, total, vencimento, valorMinuto);
    }
    
    public void show(){
        System.out.println("\nLista de telefones: ");
        
        this.telefones.forEach(t -> {
            t.showTelefone2();
        });
    }
    
    public void searchByNumber(){
        Scanner read = new Scanner(System.in);
        String numero;
        
        System.out.println("\nConsultar telefone por numero.");
        System.out.print("Informe o numero: ");
        numero = read.nextLine();
        
        this.telefones.forEach(t -> {
            if (t.getNumero().equals(numero)) {
                t.showTelefone();
                t.getListaContas();
            }
        });
    }
}
