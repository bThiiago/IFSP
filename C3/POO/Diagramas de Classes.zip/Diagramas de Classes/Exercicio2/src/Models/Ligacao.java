
package Models;

import java.util.Scanner;

/**
 *
 * @author Thiiago
 */

public class Ligacao {
    private int dia;
    private String hora;
    private int duracao;
    private String numeroTel;
    
    public Ligacao(){}
    
    public Ligacao(int dia, String hora, int duracao, String numeroTel){
        this.dia = dia;
        this.hora = hora;
        this.duracao = duracao;
        this.numeroTel = numeroTel;
    }
    
    public int getDia(){
        return dia;
    }
    
    public void setDia(int dia){
        this.dia = dia;
    }
    
    public String getHora(){
        return hora;
    }
    
    public void setHora(String hora){
        this.hora = hora;
    }
    
    public int getDuracao(){
        return duracao;
    }
    
    public void setDuracao(int duracao){
        this.duracao = duracao;
    }
    
    public String getNumeroTel(){
        return numeroTel;
    }
    
    public void setNumeroTel(String numeroTel){
        this.numeroTel = numeroTel;
    }
    
     public void readLigacao() {
        Scanner read = new Scanner(System.in);

        System.out.print("\nDia.......: ");
        this.dia = read.nextInt();read.nextLine();
        System.out.print("Hora......: ");
        this.hora = read.nextLine();
        System.out.print("Duracao...: ");
        this.duracao = read.nextInt();read.nextLine();
        System.out.print("Numero....: ");
        this.numeroTel = read.nextLine();
    }
    
    public void showLigacao() {
        System.out.println("\nDia.......: " + this.dia);
        System.out.println("Hora......: " + this.hora);
        System.out.println("Duracao...: " + this.duracao);
        System.out.println("Numero....: " + this.numeroTel);
    }
}
