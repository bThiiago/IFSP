
package Models;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Thiiago
 */

public class Conta {
    private int ano;
    private int mes;
    private float total;
    private String vencimento;
    private float valorMinuto;

    private List<Ligacao> listaLigacoes = new ArrayList<>();
    
    public Conta(){}
    
    public Conta(int ano, int mes, float total, String vencimento, float valorMinuto){
        this.ano = ano;
        this.mes = mes;
        this.total = total;
        this.vencimento = vencimento;
        this.valorMinuto = valorMinuto;
    }
    
    public void addLigacao(int dia, String hora, int duracao, String numeroTel){
        Ligacao l = new Ligacao(dia, hora, duracao, numeroTel);
        this.listaLigacoes.add(l);
    }
    
    public List<Ligacao> getListaLigacoes(){
        return this.listaLigacoes;
    }
    
    public int getAno(){
        return ano;
    }
    
    public void setAno(int ano){
        this.ano = ano;
    }
    
    public int getMes(){
        return mes;
    }
    
    public void setMes(int mes){
        this.mes = mes;
    }
    
    public float getTotal(){
        return total;
    }
    
    public void setTotal(float total){
        this.total = total;
    }
    
    public String getVencimento(){
        return vencimento;
    }
    
    public void setVencimento(String vencimento){
        this.vencimento = vencimento;
    }
    
    public float getMinuto(){
        return valorMinuto;
    }
    
    public void setMinuto(float valorMinuto){
        this.valorMinuto = valorMinuto;
    }
    
    public void readConta() {
        Scanner read = new Scanner(System.in);

        System.out.print("\nAno............: ");
        this.ano = read.nextInt();read.nextLine();
        System.out.print("Mes............: ");
        this.mes = read.nextInt();read.nextLine();
        System.out.print("Total..........: ");
        this.total = read.nextFloat();read.nextLine();
        System.out.print("Vencimento.....: ");
        this.vencimento = read.nextLine();
        System.out.print("Valor Minuto...: ");
        this.valorMinuto = read.nextFloat();read.nextLine();
    }
    
    public void showConta() {
        System.out.println("\nAno............: " + this.ano);
        System.out.println("Mes............: " + this.mes);
        System.out.println("Total..........: " + this.total);
        System.out.println("Vencimento.....: " + this.vencimento);
        System.out.println("Valor Minuto...: " + this.valorMinuto);
    }
}
