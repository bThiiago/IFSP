
package Models;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Thiiago
 */

public class Telefone {
    private String numero;
    private String proprietario;
    private String marca;
    private String modelo;

    private List<Conta> listaContas = new ArrayList<>();
    
    public Telefone(){}
    
    public Telefone(String numero, String proprietario, String marca, String modelo){
        this.numero = numero;
        this.proprietario = proprietario;
        this.marca = marca;
        this.modelo = modelo;
    }
    
    public void Conta(int ano, int mes, float total, String vencimento, float valorMinuto){
        Conta c = new Conta(ano, mes, total, vencimento, valorMinuto);
        this.listaContas.add(c);
    }
    
    public List<Conta> getListaContas(){
        return this.listaContas;
    }
    
    public String getNumero(){
        return numero;
    }
    
    public void setNumero(String numero){
        this.numero = numero;
    }
    
    public String getProprietario(){
        return proprietario;
    }
    
    public void setProprietario(String proprietario){
        this.proprietario = proprietario;
    }
    
    public String getMarca(){
        return marca;
    }
    
    public void setMarca(String marca){
        this.marca = marca;
    }
    
    public String getModelo(){
        return modelo;
    }
    
    public void setModelo(String modelo){
        this.modelo = modelo;
    }
    
    public void readTelefone() {
        Scanner read = new Scanner(System.in);

        System.out.print("\nNumero do telefone.....: ");
        this.numero = read.nextLine();
        System.out.print("Nome do propretario....: ");
        this.proprietario = read.nextLine();
        System.out.print("Marca do telefone......: ");
        this.marca = read.nextLine();
        System.out.print("Modelo do telefone.....: ");
        this.modelo = read.nextLine();
    }
    
    public void showTelefone() {
        System.out.println("\nNumero.......: " + this.numero);
        System.out.println("Proprietario...: " + this.proprietario);
        System.out.println("Marca..........: " + this.marca);
        System.out.println("Modelo.........: " + this.modelo);
    }
    
    public void showTelefone2() {
        System.out.println("\nNumero.......: " + this.numero);
        System.out.println("Proprietario...: " + this.proprietario);
    }
}
