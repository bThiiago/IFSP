
import Controllers.TelefoneController;
import java.util.Scanner;

/**
 *
 * @author Thiiago
 */

public class Principal {
    
    public static void main(String[] args) {
        
    TelefoneController tController = new TelefoneController();
        
    Scanner read = new Scanner(System.in);

    int op;

        do {
            System.out.println("\n1 - Inserir novos telefones");
            System.out.println("2 - Apresentar uma relacao");
            System.out.println("3 - Consultar um telefone");
            System.out.println("4 - Inserir nova conta");
            System.out.println("5 - Listar ligacoes");
            System.out.println("6 - Inserir nova ligacao");
            System.out.println("7 - Total gasto de minutos");
            System.out.println("8 - Total gasto por telefone");
            System.out.println("0 - Sair do programa.");
            System.out.print("\nInforme a opcao...: ");
            op = read.nextInt();

            switch (op) {
                case 1:
                    tController.add();
                    break;
                case 2:
                    tController.show();
                    break;
                case 3:
                    tController.searchByNumber();
                    break;
                case 4:
                    tController.addAccount();
                    break;
                case 5:
                    
                    break;
                case 6:
                    
                    break;
                case 7:
                    
                    break;
                case 8:
                    
                    break;

            }
        } while (op != 0);
    }
}