
package Controllers;

/**
 *
 * @author Thiiago
 */

public class MatriculaController {
    
}
