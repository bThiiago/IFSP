
package Controllers;

/**
 *
 * @author Thiiago
 */

public class CursoController {
    
}
