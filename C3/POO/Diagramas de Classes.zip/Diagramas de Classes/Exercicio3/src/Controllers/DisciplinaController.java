
package Controllers;

/**
 *
 * @author Thiiago
 */

public class DisciplinaController {
    
}
