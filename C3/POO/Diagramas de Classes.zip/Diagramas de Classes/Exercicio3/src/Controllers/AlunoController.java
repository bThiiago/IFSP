
package Controllers;

/**
 *
 * @author Thiiago
 */

public class AlunoController {
    
}
