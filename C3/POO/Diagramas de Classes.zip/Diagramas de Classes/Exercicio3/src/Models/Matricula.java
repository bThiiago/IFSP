
package Models;

/**
 *
 * @author Thiiago
 */

public class Matricula {
    
}
