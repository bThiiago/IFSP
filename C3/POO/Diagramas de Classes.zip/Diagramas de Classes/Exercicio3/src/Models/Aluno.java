
package Models;

import java.util.Scanner;

/**
 *
 * @author Thiiago
 */

public class Aluno {
    private String prontuario;
    private String nome;
    private int anoIngresso;
    
    public Aluno(){}
    
    public Aluno(String prontuario, String nome, int anoIngresso){
    this.prontuario = prontuario;
    this.nome = nome;
    this.anoIngresso = anoIngresso;
    }
    
    public String getProntuario(){
        return prontuario;
    }
    
    public void setProntuario(String prontuario){
        this.prontuario = prontuario;
    }
    
    public String getNome(){
        return nome;
    }
    
    public void setNome(String nome){
        this.nome = nome;
    }
    
    public int getAno(){
        return anoIngresso;
    }
    
    public void setAno(int anoIngresso){
        this.anoIngresso = anoIngresso;
    }
    
    public void readConta() {
        Scanner read = new Scanner(System.in);

        System.out.print("\nProntuario...: ");
        this.prontuario = read.nextLine();
        System.out.print("Nome.........: ");
        this.nome = read.nextLine();
        System.out.print("Ingresso.....: ");
        this.anoIngresso = read.nextInt();
    }
    
    public void showConta() {
        System.out.println("\nProntuario...: " + this.prontuario);
        System.out.println("Nome.........: " + this.nome);
        System.out.println("Ingresso.....: " + this.anoIngresso);
    }
}
