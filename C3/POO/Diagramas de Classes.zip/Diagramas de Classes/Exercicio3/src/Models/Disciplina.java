
package Models;

/**
 *
 * @author Thiiago
 */

public class Disciplina {
    
}
