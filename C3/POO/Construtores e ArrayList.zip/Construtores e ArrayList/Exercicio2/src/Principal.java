
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Thiiago
 */

public class Principal {
    
        private Scanner l;
	private boolean execute;
	private List<Funcionario> funcionario;

	public static void main(String[] args) {
		new Principal();
	}
        
        private Principal() {
		l = new Scanner(System.in);
		execute = true;
		funcionario = new ArrayList<Funcionario>();

		while (execute) {
			String opcao = menu();

			if (opcao.equalsIgnoreCase("1")) {
                            cadastrar();
			} else if (opcao.equalsIgnoreCase("2")) {
                            holerith();
                        } else if (opcao.equalsIgnoreCase("3")) {
                            folhaPagamento();
                        } else if (opcao.equalsIgnoreCase("4")) {
                            horaExtra();
                        } else if (opcao.equalsIgnoreCase("5")) {
                            totalPrevidencia();
                        } else if (opcao.equalsIgnoreCase("6")) {
                            totalImpostoRenda();
                        } else if (opcao.equalsIgnoreCase("7")) {
                            buscaDepartamento();
			} else if (opcao.equalsIgnoreCase("x")) {
				execute = false;
			} else {
				System.out.println("\nOpção Inválida!! \n");
			}
		}
	}

	private String menu() {
		System.out.println("\n1 - Cadastrar 10 funcionários");
		System.out.println("2 - Apresentar o holerith de um funcionário");
		System.out.println("3 - Apresentar o valor total da folha de pagamento");
		System.out.println("4 - Apresentar todos os funcionários que fizeram horas extras");
		System.out.println("5 - Apresentar o total a ser pago de contribuição previdenciária");
		System.out.println("6 - Apresentar o total a ser pago de IR");
		System.out.println("7 - Apresentar todos os funcionários de um determinado departamento");
		System.out.println("X - Sair");
                System.out.print("Selecione a opção: ");
		return l.nextLine();
	}

	private void cadastrar() {
		int cadastrando = 0;

		while (cadastrando <= 1) {
			Funcionario f = new Funcionario();
			f.setNome(textInput("\nNome................: "));
			f.setDepartamento(textInput("Departamento........: "));
                        System.out.print ("Registro............: ");
                        f.setRegistro(l.nextInt()); l.nextLine();
                        System.out.print ("Valor da hora.......: ");
                        f.setValor(l.nextFloat()); l.nextLine();
                        System.out.print ("Horas trabalhadas...: ");
                        f.setHora(l.nextInt()); l.nextLine();
                        
                        String cadastrar = textInput("\nAdicionar cadastro (S/N): ");
                        
                        
                        if (cadastrar.equalsIgnoreCase("s")) {
                            System.out.println("Cadastro adicionado!!");
                            funcionario.add(f);
                            cadastrando++;
                        } else if (cadastrar.equalsIgnoreCase("n")){
                            System.out.println("Cadastro ignorado!!");
                        } else {
                            System.out.println("\nOpção inválida, vou ignorar o cadastro só pra você ter que digitar novamente!!");
                        }
		}
        }
        
        private void holerith() {
            System.out.print("\nInforme o registro do funcionário: ");
            int registroBusca = l.nextInt(); l.nextLine();
            int confirma = 0;
            
            for (int i = 0; i < funcionario.size(); i++) {
                Funcionario f = funcionario.get(i);
                if (f.getRegistro() == registroBusca) {
                       System.out.println("\nFuncionário........: " + f.getNome());
                       System.out.println("Salário bruto......: " + f.salarioBruto());
                       System.out.println("Imposto de renda...: " + f.impostoRenda());
                       System.out.println("INSS...............: " + f.previdencia());
                       System.out.println("Salário líquido....: " + f.salarioLiquido());
                       confirma = 1;
                }
            }
            if (confirma == 0) {
                 System.out.println("\nNão existe nenhum funcionário com esse registro!!\n"); 
            }
        }
        
        private void folhaPagamento() {
            double total = 0; 
            for (int i = 0; i < funcionario.size(); i++) {
                Funcionario f = funcionario.get(i);
                total = total + f.salarioBruto();
            }
            System.out.println("\nValor total da folha de pagamento: " + total);
        }
        
        private void horaExtra() {
            System.out.println("\nFuncionários com hora extra: ");
            int confirm = 0;
            for (int i = 0; i < funcionario.size(); i++) {
                Funcionario f = funcionario.get(i);
                if (f.getHora() > 220) {
                    System.out.println("  " + f.getNome() + "  -  " + f.getHora() + " Horas.");
                    confirm = 1;
                }
            }
            if (confirm == 0) {
                System.out.println("Infelizmente nenhum funcionário fez hora extra :/");
            }
        }
        
        private void totalPrevidencia() {
            double total = 0; 
            for (int i = 0; i < funcionario.size(); i++) {
                Funcionario f = funcionario.get(i);
                total = total + f.previdencia();
            }
            System.out.println("\nTotal a ser pago de contribuição previdenciária: " + total);
        }
        
        private void totalImpostoRenda() {
            double total = 0; 
            for (int i = 0; i < funcionario.size(); i++) {
                Funcionario f = funcionario.get(i);
                total = total + f.impostoRenda();
            }
            System.out.println("\nTotal a ser pago de imposto de renda: " + total);
        }
        
        private void buscaDepartamento() {
            System.out.print("\nInforme o departamento: ");
            String departBusca = l.nextLine();
            int confirma = 0;
            
            for (int i = 0; i < funcionario.size(); i++) {
                Funcionario f = funcionario.get(i);
                if (f.getDepartamento().equals(departBusca)) {
                       System.out.println("\nFuncionário..........: " + f.getNome());
                       System.out.println("Departamento.........: " + f.getDepartamento());
                       System.out.println("Numero de Registro...: " + f.getRegistro());
                       System.out.println("Valor da hora........: " + f.getValor());
                       System.out.println("Horas trabalhadas....: " + f.getHora());
                       confirma = 1;
                }
            }
            if (confirma == 0) {
                 System.out.println("\nO departamento não existe!!"); 
            }
        }
        
        private String textInput(String label) {
		System.out.print(label);
		return l.nextLine();
	}
}
