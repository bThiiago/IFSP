
/**
 *
 * @author Thiiago
 */

public class Funcionario {
    
    private String nome;
    private String departamento; 
    private int numRegistro;
    private float valorHora;
    private int qntHora;
   
   public Funcionario(){
   
   }
   
   public String getNome(){
   
   return nome;
   }
   
   public void setNome(String nom){
   
   nome = nom;
   }
   
   public String getDepartamento(){
   
   return departamento;
   }
   
   public void setDepartamento(String depart){
   
   departamento = depart;
   }
   
   public int getRegistro(){
   
   return numRegistro;
   }
   
   public void setRegistro(int registro){
   
   numRegistro = registro;
   }
   
   public float getValor(){
   
   return valorHora;
   }
   
   public void setValor(float valor){
   
   valorHora = valor;
   }
   
   public int getHora(){
   
   return qntHora;
   }
   
   public void setHora(int hora){
   
   qntHora = hora;
   }
   
   public int horaExtra(){
       int extra = 0;
       if (qntHora > 220) {
           extra = qntHora - 220;
       }
       
    return extra;
   }
   
   public double valorExtra(){
       double valor = 0;
       int extra = horaExtra();
       
       valor = (valorHora * 1.5) * extra;
       
    return valor;
   }
   
   public double salarioBruto(){
       double salario = 0;
       if (qntHora >= 220) {
           salario = 220 * valorHora + valorExtra();
       } else if (qntHora < 220){
           salario = qntHora * valorHora;
       }
       
    return salario;
   }
   
   public double impostoRenda(){
       double valorIR = 0;
       double compara = salarioBruto();
       if (compara <= 1903.98) {
           valorIR = salarioBruto();
       } else if (compara >= 1903.99 && compara <= 2826.65){
           valorIR = salarioBruto() * 1.075;
       } else if (compara >= 2826.66 && compara <= 3751.05){
           valorIR = salarioBruto() * 1.15;
       } else if (compara >= 3751.06 && compara <= 4664.68){
           valorIR = salarioBruto() * 1.225;
       } else if (compara > 4664.68){
           valorIR = salarioBruto() * 1.275;
       }
       valorIR = valorIR - salarioBruto();
       
    return valorIR;
   }
   
   public double previdencia(){
       double valorPrev = 0;
       double compara = salarioBruto();
       if (compara <= 1750.00) {
           valorPrev = salarioBruto() * 1.08;
       } else if (compara >= 1750.01 && compara <= 2920.00){
           valorPrev = salarioBruto() * 1.09;
       } else if (compara > 2920.00){
           valorPrev = salarioBruto() * 1.11;
       }
       valorPrev = valorPrev - salarioBruto();
       
    return valorPrev;
   }
   
   public double salarioLiquido(){
       double liquido = 0;
       liquido = salarioBruto() - impostoRenda() - previdencia();
       
    return liquido;
   }
}
