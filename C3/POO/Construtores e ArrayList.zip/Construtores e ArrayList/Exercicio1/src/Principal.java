
import java.util.List;
import java.util.Scanner;
import java.util.ArrayList;

/**
 *
 * @author Thiiago
 */

public class Principal {
    
        private Scanner l;
	private boolean execute;
	private List<Veiculo> veiculo;
        private int Vagas[] = new int[25];

	public static void main(String[] args) {
		new Principal();
	}
        
        private Principal() {
		l = new Scanner(System.in);
		execute = true;
		veiculo = new ArrayList<Veiculo>();

		System.out.println("BEM VINDO AO CADASTRO DE VEICULOS - (VAGAS DE 0 à 24)");

		while (execute) {
			String opcao = menu();

			if (opcao.equalsIgnoreCase("1")) {
				cadastrar();
			} else if (opcao.equalsIgnoreCase("2")) {
				listarCadastros();
                        } else if (opcao.equalsIgnoreCase("3")) {
				pesquisaVagas();
                        } else if (opcao.equalsIgnoreCase("4")) {
				pesquisaPlaca();
                        } else if (opcao.equalsIgnoreCase("5")) {
				pesquisaMarca();
                        } else if (opcao.equalsIgnoreCase("6")) {
				quantidadeVeiculos();
                        } else if (opcao.equalsIgnoreCase("7")) {
				vagasDisponiveis();
			} else if (opcao.equalsIgnoreCase("x")) {
				execute = false;
			} else {
				System.out.println("\nOpção Inválida!! \n");
			}
		}
	}

	private String menu() {
		System.out.println("\n1 - Cadastrar novo veiculo");
		System.out.println("2 - Apresentar relação dos veiculos");
		System.out.println("3 - Pesquisa por vaga disponível");
		System.out.println("4 - Localizar vaga através da placa");
		System.out.println("5 - Pesquisar veículos por marca");
		System.out.println("6 - Apresentar quantidade de veiculos no estacionamento");
		System.out.println("7 - Informar quantas vagas estão disponíveis");
		System.out.println("X - Sair");
                System.out.print("Selecione a opção: ");
		return l.nextLine();
	}

	private void cadastrar() {
		boolean cadastrando = true;
                int verif;

		while (cadastrando) {
			System.out.println("\nCadastro de Veiculo");
			Veiculo v = new Veiculo();
			v.setPlaca(textInput("Placa..: "));
			v.setMarca(textInput("Marca..: "));
                        System.out.print ("Vaga...: ");
                        v.setVaga(l.nextInt()); l.nextLine();
                        
                        verif = v.getVaga();
                        
                        if (Vagas[verif] == 1) {
                            System.out.println("A vaga já está ocupada!!");
                        } else if (Vagas[verif] == 0) {
                            Vagas[verif] = 1;
                            
                            String cadastrar = textInput("\nAdicionar cadastro (S/N): ");
                        
                            if (cadastrar.equalsIgnoreCase("s")) {
                                    System.out.println("Cadastro adicionado!!");
                                    veiculo.add(v);
                            } else if (cadastrar.equalsIgnoreCase("n")){
                                    System.out.println("Cadastro ignorado!!");
                                    Vagas[verif] = 0;
                            } else {
                                    System.out.println("\nOpção inválida, vou ignorar o cadastro só pra você ter que digitar novamente!! \n");
                                    Vagas[verif] = 0;
                            }
                        }

			String continua = textInput("Continuar cadastrando (S/N): ");
			if (continua.equalsIgnoreCase("N")) {
				cadastrando = false;
			} else if (continua.equalsIgnoreCase("s")){
                            
			} else {
				System.out.println("\nOpção inválida, eu vou sair só porque você não colabora!! \n");
				cadastrando = false;
			}
		}
        }

	private void listarCadastros() {
		if (veiculo.size() == 0) {
			System.out.println("\nNão existem cadastros!!\n");
		} else {
			System.out.println("\nLista de Cadastros\n");
			for (int i = 0; i < veiculo.size(); i++) {
				Veiculo v = veiculo.get(i);
				System.out.println("   Cadastro número: " + i);
				System.out.println("\tPlaca: " + v.getPlaca());
				System.out.println("\tMarca: " + v.getMarca());
				System.out.println("\tVaga: " + v.getVaga() + "\n");
			}
			System.out.println("Fim da lista\n");
		}
	}
        
        private void pesquisaVagas() {
            
            System.out.println("Digite o numero da vaga (0 à 24): ");
            int pesquisa = (l.nextInt()); l.nextLine();
            
            if (pesquisa >= 26) {
                System.out.println("\nOpção inválida, eu vou sair só porque você não colabora!! \n");
            }else {
                    if (Vagas[pesquisa] == 1) {
                        System.out.println("\n\nA vaga " + pesquisa + " está ocupada!!\n");
                    } else {
                        System.out.println("\n\nA vaga " + pesquisa + " está disponível!!\n");
                    }
            }
        }
        
        private void pesquisaPlaca() {
            System.out.print("\n\nInforme a placa do veículo: ");
            String placaBusca = l.nextLine();
            int confirma = 0;
            
            for (int i = 0; i < veiculo.size(); i++) {
                Veiculo v = veiculo.get(i);
                if (v.getPlaca().equals(placaBusca)) {
                       System.out.println("\nO veiculo se localiza na vaga " + v.getVaga() + ".\n"); 
                       confirma = 1;
                }
            }
            if (confirma == 0) {
                 System.out.println("\nEstá placa não está cadastrada!!\n"); 
            }
        }
        
        private void pesquisaMarca() {
            System.out.print("\n\nInforme a marca do veículo: ");
            String marcaBusca = l.nextLine();
            int confirma = 0;
            
            for (int i = 0; i < veiculo.size(); i++) {
                Veiculo v = veiculo.get(i);
                if (v.getMarca().equals(marcaBusca)) {
                    System.out.println("\tPlaca: " + v.getPlaca());
                    System.out.println("\tMarca: " + v.getMarca());
                    System.out.println("\tVaga: " + v.getVaga() + "\n");
                    confirma = 1;
                }
            }
            if (confirma == 0) {
                 System.out.println("\nNão existem veículos desta marca!!\n"); 
            }
        }
        
        private void quantidadeVeiculos() {
            int qnt = veiculo.size();
            if (qnt > 0) {
                System.out.println("\nHá um total de " + qnt + " veículo(s) no estacionamento.");
            } else if (qnt == 0){
                System.out.println("\nNão existem veículos no estacionamento.");
            }
        }
        
        private void vagasDisponiveis() {
            int qnt = 0;
            for (int i = 0; i < Vagas.length; i++) {
                if (Vagas[i] == 0) {
                    qnt++;
                }
            }
            if (qnt > 0) {
                System.out.println("\nExiste um total de " + qnt + " vaga(s) livre(s).");
            } else if (qnt == 0){
                System.out.println("\nNão existem vagas livres.");
            }
        }

	private String textInput(String label) {
		System.out.print(label);
		return l.nextLine();
	}
}
