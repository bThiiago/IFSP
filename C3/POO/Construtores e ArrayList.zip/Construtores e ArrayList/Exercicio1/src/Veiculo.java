
/**
 *
 * @author Thiiago
 */

public class Veiculo {
    
    private String placa;
    private String marca; 
    private int vaga;
   
   public Veiculo(){
   
   }
   
   public String getPlaca(){
   
   return placa;
   }
   
   public void setPlaca(String plac){
   
   placa = plac;
   }
   
   public String getMarca(){
   
   return marca;
   }
   
   public void setMarca(String marc){
   
   marca = marc;
   }
   
   public int getVaga(){
   
   return vaga;
   }
   
   public void setVaga(int vag){
   
   vaga = vag;
   }
   
}