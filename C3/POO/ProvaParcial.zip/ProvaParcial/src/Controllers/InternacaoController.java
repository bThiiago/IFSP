
package Controllers;

import Models.Internacao;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Thiiago
 */

public class InternacaoController {
    ArrayList<Internacao> internacoes = new ArrayList<>();
    
    public InternacaoController(){}
    
    public double getTotalInternacoes(double total) {
        for (Internacao i : internacoes) {
            total = i.getTotalInternacao();
        }
        return total;
    }
    
    public void readInternacoes() {
        Internacao i = new Internacao();
        i.readInternacoes();
        this.internacoes.add(i);
    }
    
    public void showInternacoes() {
        for (Internacao i : internacoes) {
            i.showInternacoes();
        }
    }
    
    public List<Internacao> getInternacoes() {
        return this.internacoes;
    }
}
