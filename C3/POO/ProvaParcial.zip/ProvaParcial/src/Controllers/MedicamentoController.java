
package Controllers;

import Models.Medicamento;
import java.util.ArrayList;

/**
 *
 * @author Thiiago
 */

public class MedicamentoController {
    ArrayList<Medicamento> medicamentos = new ArrayList<>();
    
    public MedicamentoController(){}

    public void readMedicamento() {
        Medicamento m1, m2, m3, m4;
        m1 = new Medicamento(123, "Codeina", "Paralelepipedo", 100);
        m2 = new Medicamento(456, "Bascal", "Quadrado", 100);
        m3 = new Medicamento(789, "Sabonete", "Triangulo", 100);
        m4 = new Medicamento(007, "Escocia", "Redondeta", 100);
        this.medicamentos.add(m1);
        this.medicamentos.add(m2);
        this.medicamentos.add(m3);
        this.medicamentos.add(m4);
    }

    public void showMedicamento() {
        for (Medicamento m : medicamentos) {
            m.showMedicamento();
        }
    }
    
    public ArrayList<Medicamento> getMedicamentos() {
        return this.medicamentos;
    }
    
    public Medicamento getCodBarras(int codigo) {
        for (Medicamento m : medicamentos) {
            if (m.getCodigo() == codigo) {
                return m;
            }
        }
        return null;
    }
}