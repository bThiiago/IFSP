
package Screen;

import Controllers.InternacaoController;
import Controllers.MedicamentoController;
import java.util.Scanner;

/**
 *
 * @author Thiiago
 */

public class Principal {
    
    public static void main(String[] args) {
        
    Scanner read = new Scanner(System.in);
    
    InternacaoController ic = new InternacaoController();
    MedicamentoController mc = new MedicamentoController();

    int cod;
    int op;

        do {
            System.out.println("\n1 - Cadastrar");
            System.out.println("2 - Apresentar");
            System.out.println("3 - Localizar");
            System.out.println("0 - Sair do programa");
            System.out.print("\nInforme a opcao...: ");
            op = read.nextInt();
            System.out.println("");
            
            switch (op) {
                case 1:
                    ic.readInternacoes();
                    break;
                case 2:
                    ic.showInternacoes();
                    break;
                case 3:
                    System.out.println("Codigo de barras para localizar...: ");
                    cod = read.nextInt();
                    
                    mc.getCodBarras(cod);
                    break;
            }
        } while (op != 0);
    }
}
