
package Models;

import java.util.Scanner;

/**
 *
 * @author Thiiago
 */

public class Medicamento {
    private int codBarras;
    private String nome;
    private String composicao;
    private double precoEstimado;
    
    public Medicamento(){}
    
    public Medicamento(int codBarras, String nome, String composicao, double precoEstimado){
        this.codBarras = codBarras;
        this.nome = nome;
        this.composicao = composicao;
        this.precoEstimado = precoEstimado;
    }
    
    public void readMedicamento() {
        Scanner read = new Scanner(System.in);

        System.out.print("Digite o codigo de barras......: ");
        this.codBarras = read.nextInt(); read.nextLine();

        System.out.print("Digite o nome do medicamento...: ");
        this.nome = read.nextLine();
        
        System.out.print("Digite a composicao dele.......: ");
        this.composicao = read.nextLine();

        System.out.print("Digite o preco estimado........: ");
        this.precoEstimado = read.nextDouble(); read.nextLine();
    }
    
    public void showMedicamento() {
        System.out.println("Codigo de barras......: " + this.codBarras);
        System.out.println("Nome do medicamento...: " + this.nome);
        System.out.println("Composicao dele.......: " + this.composicao);
        System.out.println("Preco estimado........: " + this.precoEstimado);
    }
    
    public int getCodigo(){
        return codBarras;
    }
    
    public void setCodigo(int codBarras){
        this.codBarras = codBarras;
    }
    
    public String getNome(){
        return nome;
    }
    
    public void setNome(String nome){
        this.nome = nome;
    }
    
    public String getComposicao(){
        return composicao;
    }
    
    public void setComposicao(String composicao){
        this.composicao = composicao;
    }
    
    public double getPreco(){
        return precoEstimado;
    }
    
    public void setPreco(double precoEstimado){
        this.precoEstimado = precoEstimado;
    }
}
