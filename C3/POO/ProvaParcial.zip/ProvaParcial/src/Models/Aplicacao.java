
package Models;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Thiiago
 */

public class Aplicacao implements Gastos {
    private int quantidade;
    private double preco;
    
    private Medicamento medicamentos;
    
    ArrayList<Medicamento> listaMedicamentos = new ArrayList<>();
    
    public Aplicacao(){}
    
    public Aplicacao(int quantidade, double preco, Medicamento medicamentos){
        this.quantidade = quantidade;
        this.preco = preco;
        this.medicamentos = medicamentos;
    }
    
    public void readAplicacao() {
        Scanner read = new Scanner(System.in);

        System.out.print("Quantidade...: ");
        this.quantidade = read.nextInt(); read.nextLine();

        System.out.print("Preco........: ");
        this.preco = read.nextDouble(); read.nextLine();
    }
    
    public void showMedicamento() {
        System.out.println("Quantidade...: " + this.quantidade);
        System.out.println("Preco........: " + this.preco);
    }
    
    public Medicamento getMedicamento(){
        return medicamentos;
    }
    
    public void setMedicamento(Medicamento medicamentos){
        this.medicamentos = medicamentos;
    }
    
    public int getQuantidade(){
        return quantidade;
    }
    
    public void setQuantidade(int quantidade){
        this.quantidade = quantidade;
    }
    
    public double getPreco(){
        return preco;
    }
    
    public void setPreco(double preco){
        this.preco = preco;
    }
    
    @Override
    public String getDescricao(){
        return medicamentos.getNome() + " - " + this.quantidade + " X R$" + this.preco + " - R$" + getValor();
    }
    
    @Override
    public double getValor(){
        return this.quantidade*this.preco;
    }
}