
package Models;

import java.util.Scanner;

/**
 *
 * @author Thiiago
 */

public class Exame implements Gastos{
    private String nome;
    private String localCorpo;
    private double preco;
    
    public Exame(){}
    
    public Exame(String nome, String localCorpo, double preco){
        this.nome = nome;
        this.localCorpo = localCorpo;
        this.preco = preco;
    }
    
    public void readExame() {
        Scanner read = new Scanner(System.in);

        System.out.print("Nome do exame....: ");
        this.nome = read.nextLine();

        System.out.print("Local do corpo...: ");
        this.localCorpo = read.nextLine();

        System.out.print("Preco do exame...: ");
        this.preco = read.nextDouble(); read.nextLine();
    }
    
    public void showMedicamento() {
        System.out.println("Nome do exame....: " + this.nome);
        System.out.println("Local do corpo...: " + this.localCorpo);
        System.out.println("Preco do exame...: " + this.preco);
    }
    
    public String getNome(){
        return nome;
    }
    
    public void setNome(String nome){
        this.nome = nome;
    }
    
    public String getLocal(){
        return localCorpo;
    }
    
    public void setLocal(String localCorpo){
        this.localCorpo = localCorpo;
    }
    
    public double getPreco(){
        return preco;
    }
    
    public void setPreco(double preco){
        this.preco = preco;
    }

    @Override
    public String getDescricao(){
        return " Exame: " + this.nome + " - " + this.localCorpo + " - R$" + this.preco;
    }
    
    @Override
    public double getValor(){
        return this.preco;
    }
}
