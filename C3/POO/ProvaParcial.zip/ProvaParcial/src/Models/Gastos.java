
package Models;

/**
 *
 * @author Thiiago
 */

public interface Gastos {
    public String getDescricao();
    public double getValor();
}
