
package Models;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Thiiago
 */

public class Internacao {
    private String dataInicio;
    private String horaInicio;
    private String motivo;
    private int diarias;
    
    private Exame exames;
    private Aplicacao aplicacoes;
    private Medicamento medicamentos;
    private Gastos gastos;
    
    ArrayList<Exame> listaExames = new ArrayList<>();
    ArrayList<Aplicacao> listaAplicacoes = new ArrayList<>();
    ArrayList<Gastos> listaGastos = new ArrayList<>();
    
    public Internacao(){}
    
    public Internacao(String dataInicio, String horaInicio, String motivo, int diarias, Exame exames, Aplicacao aplicacoes){
        this.dataInicio = dataInicio;
        this.horaInicio = horaInicio;
        this.motivo = motivo;
        this.diarias = diarias;
        this.exames = exames;
        this.aplicacoes = aplicacoes;
    }
    
    public void readInternacoes() {
        Scanner read = new Scanner(System.in);

        System.out.print("Data de inicio da internacao...: ");
        this.dataInicio = read.nextLine();

        System.out.print("Hora de inicio da internacao...: ");
        this.horaInicio = read.nextLine();

        System.out.print("Motivo da internacao...........: ");
        this.motivo = read.nextLine();
        
        System.out.print("Diarias da internacao..........: ");
        this.diarias = read.nextInt(); read.nextLine();
    }
    
    public void showInternacoes() {
        System.out.println("Data de inicio...: " + this.dataInicio);
        System.out.println("Hora de inicio...: " + this.horaInicio);
        System.out.println("Motivo...........: " + this.motivo);
        System.out.println("Diarias..........: " + this.diarias);
    }
    
    public Exame getExame(){
        return exames;
    }
    
    public void setExame(Exame exames){
        this.exames = exames;
    }
    
    public Aplicacao getAplicacao(){
        return aplicacoes;
    }
    
    public void setAplicacao(Aplicacao aplicacoes){
        this.aplicacoes = aplicacoes;
    }
    
    public void addExame(String nome, String localCorpo, double preco) {
        Exame e = new Exame(nome, localCorpo, preco);
        e.readExame();
        this.listaExames.add(e);
    }
    
    public void addAplicacao(int quantidade, double preco, Medicamento medicamentos){
        Aplicacao a = new Aplicacao(quantidade, preco, medicamentos);
        a.readAplicacao();
        this.listaAplicacoes.add(a);
    }
    
    public String getData(){
        return dataInicio;
    }
    
    public void setData(String dataInicio){
        this.dataInicio = dataInicio;
    }
    
    public String getHora(){
        return horaInicio;
    }
    
    public void setHora(String horaInicio){
        this.horaInicio = horaInicio;
    }
    
    public String getMotivo(){
        return motivo;
    }
    
    public void setMotivo(String motivo){
        this.motivo = motivo;
    }
    
    public int getDiarias(){
        return diarias;
    }
    
    public void setDiarias(int diarias){
        this.diarias = diarias;
    }
    
    public double getTotalGastoMedicacao() {
        return aplicacoes.getValor();
    }
            
    public double getTotalGastoExames() {
        return exames.getValor();
    }
            
    public double getTotalDiarias() {
        return this.diarias*420;
    }
            
    public double getTotalInternacao() {
        return getTotalDiarias() + getTotalGastoExames() + getTotalGastoMedicacao();
    }
    
    public List<Gastos> getRelacaoGastos() {
        this.listaGastos.addAll(listaExames);
        this.listaGastos.addAll(listaAplicacoes);
        
        for (Gastos g : listaGastos) {
            System.out.println(g.getDescricao());
        }
        return listaGastos;
    }
}