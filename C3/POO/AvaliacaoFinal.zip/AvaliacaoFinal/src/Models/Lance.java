
package Models;

import java.util.Scanner;

/**
 *
 * @author Thiiago
 */

public class Lance {
    private double valorLance;
    private String nome;
    
    public Lance(){}

    public Lance(double valorLance, String nome) {
        this.valorLance = valorLance;
        this.nome = nome;
    }
    
    public void read() {
        Scanner read = new Scanner(System.in);

        System.out.print("Informe o valor do lance...: ");
        this.valorLance = read.nextDouble(); read.nextLine();

        System.out.print("Informe o nome.............: ");
        this.nome = read.nextLine();
    }

    public void show() {
        System.out.println("Valor do Lance...: " + this.valorLance);
        System.out.println("Nome.............: " + this.nome);
    }
    
    public double getValorLance() {
        return valorLance;
    }

    public void setValorLance(double valorLance) {
        this.valorLance = valorLance;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
}
