
package Models;

import java.util.Scanner;

/**
 *
 * @author Thiiago
 */

public class Veiculo extends ProdutoBase {
    private String marca;
    private String modelo;
    private int ano;
    private String localizacao;
    
    public Veiculo(){}

    public Veiculo(int codigo, String descricao, double ultimoLance, String marca, String modelo, int ano, String localizacao) {
        super(codigo, descricao, ultimoLance);
        this.marca = marca;
        this.modelo = modelo;
        this.ano = ano;
        this.localizacao = localizacao;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public String getLocalizacao() {
        return localizacao;
    }

    public void setLocalizacao(String localizacao) {
        this.localizacao = localizacao;
    }
    
    @Override
    public void read() {
        super.read();
        
        Scanner read = new Scanner(System.in);
        
        System.out.print("Marca.........: ");
        this.marca = read.nextLine();
        
        System.out.print("Modelo........: ");
        this.modelo = read.nextLine();

        System.out.print("Ano...........: ");
        this.ano = read.nextInt(); read.nextLine();
        
        System.out.print("Localizacao...: ");
        this.localizacao = read.nextLine();
    }
    
    @Override
    public void show() {
        super.show();
        
        System.out.println("Marca.........: " + this.marca);
        System.out.println("Modelo........: " + this.modelo);
        System.out.println("Ano...........: " + this.ano);
        System.out.println("Localizacao...: " + this.localizacao);
    }
    
    @Override
    public void apresentarProduto(){
        System.out.println("Marca.........: " + this.marca);
        System.out.println("Modelo........: " + this.modelo);
        System.out.println("Ano...........: " + this.ano);
        System.out.println("Localizacao...: " + this.localizacao);
    }
}
