
package Models;

import java.util.Scanner;

/**
 *
 * @author Thiiago
 */

public class Imovel extends ProdutoBase {
    private double valorVenal;
    private String endereco;
    
    public Imovel(){}

    public Imovel(int codigo, String descricao, double ultimoLance, double valorVenal, String endereco) {
        super(codigo, descricao, ultimoLance);
        this.valorVenal = valorVenal;
        this.endereco = endereco;
    }

    public double getValorVenal() {
        return valorVenal;
    }

    public void setValorVenal(double valorVenal) {
        this.valorVenal = valorVenal;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }
    
    @Override
    public void read() {
        super.read();
        
        Scanner read = new Scanner(System.in);
        
        System.out.print("Valor venal...: ");
        this.valorVenal = read.nextDouble(); read.nextLine();
        
        System.out.print("Endereco......: ");
        this.endereco = read.nextLine();
    }
    
    @Override
    public void show() {
        super.show();
        
        System.out.println("Valor venal...: " + this.valorVenal);
        System.out.println("Endereco......: " + this.endereco);
    }
    
    @Override
    public void apresentarProduto(){
        System.out.println("Valor venal...: " + this.valorVenal);
        System.out.println("Endereco......: " + this.endereco);
    }
}
