
package Models;

import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Thiiago
 */

public abstract class ProdutoBase {
    private int codigo;
    private String descricao;
    private double ultimoLance;
    
    private ArrayList<Lance> listaLances = new ArrayList<>();
    
    public ProdutoBase(){}

    public ProdutoBase(int codigo, String descricao, double ultimoLance) {
        this.codigo = codigo;
        this.descricao = descricao;
        this.ultimoLance = ultimoLance;
    }
    
    public void read() {
        Scanner read = new Scanner(System.in);

        System.out.print("\nCodigo........: ");
        this.codigo = read.nextInt(); read.nextLine();
        
        System.out.print("Descricao.....: ");
        this.descricao = read.nextLine();

        System.out.print("Ultimo lance...: ");
        this.ultimoLance = read.nextDouble(); read.nextLine();
    }
    
    public void show() {
        System.out.println("\nCodigo.........: " + this.codigo);
        System.out.println("Descricao......: " + this.descricao);
        System.out.println("Ultimo lance...: " + this.ultimoLance);
    }
    
    public abstract void apresentarProduto();

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public double getUltimoLance() {
        return ultimoLance;
    }

    public void setUltimoLance(double ultimoLance) {
        this.ultimoLance = ultimoLance;
    }

    public ArrayList<Lance> getListaLances() {
        return listaLances;
    }

    public void setListaLances(ArrayList<Lance> listaLances) {
        this.listaLances = listaLances;
    }
    
    public void addLance(double valor, String nome){
        Lance l = new Lance(valor, nome);
        l.read();
        this.listaLances.add(l);
    }
}