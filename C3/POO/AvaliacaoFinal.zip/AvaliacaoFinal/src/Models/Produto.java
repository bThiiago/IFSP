
package Models;

import java.util.Scanner;

/**
 *
 * @author Thiiago
 */

public class Produto extends ProdutoBase {
    private String fabricante;
    
    public Produto(){}

    public Produto(int codigo, String descricao, double ultimoLance, String fabricante) {
        super(codigo, descricao, ultimoLance);
        this.fabricante = fabricante;
    }

    public String getFabricante() {
        return fabricante;
    }

    public void setFabricante(String fabricante) {
        this.fabricante = fabricante;
    }
  
    @Override
    public void read() {
        super.read();
        
        Scanner read = new Scanner(System.in);
        
        System.out.print("Fabricante...: ");
        this.fabricante = read.nextLine();
    }
    
    @Override
    public void show() {
        super.show();
        
        System.out.println("Fabricante...: " + this.fabricante);
    }
    
    @Override
    public void apresentarProduto(){
        System.out.println("Fabricante...: " + this.fabricante);
    }
}
