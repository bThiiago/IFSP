CREATE DATABASE final;
USE final;

CREATE TABLE Produto (
    codigo_pro INT PRIMARY KEY NOT NULL,
    descricao VARCHAR(100) NOT NULL,
    tipo CHAR(1),
    valor DOUBLE NOT NULL,
    endereco VARCHAR(100),
    marca VARCHAR(20),
    modelo VARCHAR(20),
    ano INT,
    valorLance DOUBLE
);

CREATE TABLE Lance (
    num_lance int NOT NULL AUTO_INCREMENT,
    valor DOUBLE,
    nome_pessoa VARCHAR(50),
    codigo_pro INT NOT NULL,
    PRIMARY KEY (num_lance)
);

ALTER TABLE Lance ADD CONSTRAINT fk_ProLan FOREIGN KEY (codigo_pro) REFERENCES Produto (codigo_pro);