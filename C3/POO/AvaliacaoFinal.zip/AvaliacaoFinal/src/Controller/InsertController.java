
package Controller;

import java.sql.Connection;
import java.sql.PreparedStatement;
import Models.Imovel;
import Models.Lance;
import Models.Produto;
import Models.ProdutoBase;
import Models.Veiculo;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Thiiago
 */

public class InsertController {
    
    public void includeImovel(Imovel i) throws SQLException {
        Connection conexao = ConnectionController.getConexao();

        String comandoSQL = "INSERT INTO Produto (codigo_pro, descricao, valorLance, endereco, valor, tipo) VALUES (?,?,?,?,?,?)";

        PreparedStatement execSQL;
        execSQL = conexao.prepareStatement(comandoSQL);

        execSQL.setInt(1, i.getCodigo());
        execSQL.setString(2, i.getDescricao());
        execSQL.setDouble(3, i.getUltimoLance());
        execSQL.setString(5, i.getEndereco());
        execSQL.setDouble(6, i.getUltimoLance());
        execSQL.setString(7, "I");

        execSQL.executeUpdate();
        conexao.commit();
        execSQL.close();
        conexao.close();
    }
    
    public void includeVeiculo(Veiculo v) throws SQLException {
        Connection conexao = ConnectionController.getConexao();

        String comandoSQL = "INSERT INTO Produto (codigo_pro, descricao, valorLance, marca, modelo, ano, localizacao, valor, tipo) VALUES (?,?,?,?,?,?,?,?,?)";

        PreparedStatement execSQL;
        execSQL = conexao.prepareStatement(comandoSQL);

        execSQL.setInt(1, v.getCodigo());
        execSQL.setString(2, v.getDescricao());
        execSQL.setDouble(3, v.getUltimoLance());
        execSQL.setString(4, v.getMarca());
        execSQL.setString(5, v.getModelo());
        execSQL.setInt(6, v.getAno());
        execSQL.setString(7, v.getLocalizacao());
        execSQL.setDouble(8, v.getUltimoLance());
        execSQL.setString(9, "V");

        execSQL.executeUpdate();
        conexao.commit();
        execSQL.close();
        conexao.close();
    }
    
    public void includeProduto(Produto p) throws SQLException {
        Connection conexao = ConnectionController.getConexao();

        String comandoSQL = "INSERT INTO Produto (codigo_pro, descricao, valorLance, marca, valor, tipo) VALUES (?,?,?,?,?,?)";

        PreparedStatement execSQL;
        execSQL = conexao.prepareStatement(comandoSQL);

        execSQL.setInt(1, p.getCodigo());
        execSQL.setString(2, p.getDescricao());
        execSQL.setDouble(3, p.getUltimoLance());
        execSQL.setString(4, p.getFabricante());
        execSQL.setDouble(5, p.getUltimoLance());
        execSQL.setString(6, "P");

        execSQL.executeUpdate();
        conexao.commit();
        execSQL.close();
        conexao.close();
    }
    
    public void includeLance(Lance l, int codigo) throws SQLException {
        Connection conexao = ConnectionController.getConexao();

        String comandoSQL = "INSERT INTO Lance (num_lance, valor, nome_pessoa, codigo_pro) VALUES (?,?,?,?)";

        PreparedStatement execSQL;
        execSQL = conexao.prepareStatement(comandoSQL);

        execSQL.setDouble(1, 1);
        execSQL.setDouble(2, l.getValorLance());
        execSQL.setString(3, l.getNome());
        execSQL.setInt(4, codigo);

        execSQL.executeUpdate();
        conexao.commit();
        execSQL.close();
        conexao.close();
        
        updateProduto(codigo, l.getValorLance());
    }
    
    public void updateProduto(int codigo, double valor) throws SQLException {
        Connection conexao = ConnectionController.getConexao();

        String comandoSQL = ("UPDATE Produto SET valorLance = ? WHERE codigo_pro = ?");

        PreparedStatement execSQL;
        execSQL = conexao.prepareStatement(comandoSQL);

        execSQL.setDouble(1, valor);
        execSQL.setInt(2, codigo);

        execSQL.executeUpdate();
        conexao.commit();
        execSQL.close();
        conexao.close();
    }
    
    public List<ProdutoBase> listar() throws SQLException {
        Imovel i = new Imovel();
        Veiculo v = new Veiculo();
        Produto p = new Produto();
        
        List<ProdutoBase> listaProdutosBase = new ArrayList<>();
        
        Connection conexao = ConnectionController.getConexao();

        String comandoSQL = ("SELECT * FROM Produto");

        PreparedStatement execSQL;
        execSQL = conexao.prepareStatement(comandoSQL);

        ResultSet resultadoConsulta;
        resultadoConsulta = execSQL.executeQuery();
        
        while (resultadoConsulta.next()) {
            if (resultadoConsulta.getString("tipo").equals("I")) {
                i.setCodigo(resultadoConsulta.getInt("codigo_pro"));
                i.setDescricao(resultadoConsulta.getString("descricao"));
                i.setUltimoLance(resultadoConsulta.getDouble("ultimoLance"));
                i.setEndereco(resultadoConsulta.getString("endereco"));
                listaProdutosBase.add(i);
            }
            if (resultadoConsulta.getString("tipo").equals("V")) {
                v.setCodigo(resultadoConsulta.getInt("codigo_pro"));
                v.setDescricao(resultadoConsulta.getString("descricao"));
                v.setUltimoLance(resultadoConsulta.getDouble("valorLance"));
                v.setMarca(resultadoConsulta.getString("marca"));
                v.setModelo(resultadoConsulta.getString("modelo"));
                v.setAno(resultadoConsulta.getInt("ano"));
                v.setLocalizacao(resultadoConsulta.getString("localizacao"));
                listaProdutosBase.add(v);
            }
            if (resultadoConsulta.getString("tipo").equals("P")) {
                p.setCodigo(resultadoConsulta.getInt("codigo_pro"));
                p.setDescricao(resultadoConsulta.getString("descricao"));
                p.setUltimoLance(resultadoConsulta.getDouble("valorLance"));
                p.setFabricante(resultadoConsulta.getString("marca"));
                listaProdutosBase.add(p);
            }
        }
        return listaProdutosBase;
    }
    
    public void list() throws SQLException {
        for (ProdutoBase pb : this.listar()){
            pb.show();
        }
    }

}
