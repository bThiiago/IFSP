
package Controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Thiiago
 */

public class ConnectionController {
    private static String urlBanco = "jdbc:mysql://localhost:3306/final?useSSL=false";

    public static Connection getConexao()
    {
        // estabelecer conexão com o banco de dados
        // declara um objeto de conexão
        Connection conexao = null;
        try {
            // estabelece cponexão com o banco de dados
            conexao = DriverManager.getConnection(urlBanco, "root", "1234");
            // retira o autcommit da conexão
            conexao.setAutoCommit(false);
        } catch (SQLException ex) {
            System.out.println("Não foi possível fazer a conexão com o banco");
            System.out.println(ex.getMessage());
            System.exit(0);
        }
        return conexao;
    }
    
}
