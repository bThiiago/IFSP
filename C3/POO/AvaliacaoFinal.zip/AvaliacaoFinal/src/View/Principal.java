
package View;

import Controller.InsertController;
import Models.Imovel;
import Models.Lance;
import Models.Produto;
import Models.ProdutoBase;
import Models.Veiculo;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Thiiago
 */

public class Principal {

    public static void main(String[] args) throws SQLException {
        
    try {
        Class.forName("com.mysql.cj.jdbc.Driver");
    } catch (ClassNotFoundException ex) {
        System.out.println(ex.toString());
        System.exit(0);
    }
        
    InsertController ic = new InsertController();
    ArrayList<ProdutoBase> produtos = new ArrayList<>();
        
    Scanner read = new Scanner(System.in);

    int op, cod;
    String tipo;

        do {
            System.out.println("\n1 - Inserir um produto");
            System.out.println("2 - Efetuar um lance");
            System.out.println("3 - Listar todos os lances de um produto");
            System.out.println("4 - Listar todos os produtos");
            System.out.println("0 - Sair do programa.");
            System.out.print("\nInforme a opcao...: ");
            op = read.nextInt(); read.nextLine();

            switch (op) {
                case 1:
                    System.out.println("INFORME O TIPO DO PRODUTO:");
                    System.out.println("I = Imovel");
                    System.out.println("V = Veiculo");
                    System.out.println("P = Produto\n");
                    tipo = read.nextLine();
                    
                    if ("I".equals(tipo)) {
                        Imovel i = new Imovel();
                        i.read();
                        {
                            try {
                                ic.includeImovel(i);
                            } catch (SQLException ex) {
                                Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }
                    }
                    if ("V".equals(tipo)) {
                        Veiculo v = new Veiculo();
                        v.read();
                        {
                            try {
                                ic.includeVeiculo(v);
                            } catch (SQLException ex) {
                                Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }
                    }
                    if ("P".equals(tipo)) {
                        Produto p = new Produto();
                        p.read();
                        {
                            try {
                                ic.includeProduto(p);
                            } catch (SQLException ex) {
                                Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }
                    }
                    break;
                case 2:
                    System.out.print("\nInforme o código do produto: ");
                    cod = read.nextInt(); read.nextLine();
                    
                    Lance l = new Lance();
                    l.read();
                    {
                        try {
                            ic.includeLance(l, cod);
                        } catch (SQLException ex) {
                            Logger.getLogger(Principal.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    }
                    break;
                case 3:
                   
                    break;
                case 4:
                    ic.list();
                    break;
            }
        } while (op != 0);
    }
}