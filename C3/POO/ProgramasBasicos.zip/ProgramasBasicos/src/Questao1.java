
import java.util.Scanner;

/**
 *
 * @author Thiago
 */

public class Questao1 {

    public static void main(String[] args) {

        int tam = 6;
        int maior;
        int mai = 0;
        int menor;
        int mei = 0;
        int soma = 0;
        float media;
        int[] x;
        int[] vet = new int[100];

        Scanner ler = new Scanner(System.in);

        x = new int[tam];

        for (int i = 0; i < tam; i++) {
            System.out.print("Digite o valor do vetor [" + i + "]: ");
            x[i] = ler.nextInt();
        }

        maior = x[0];

        for (int i = 0; i < tam; i++) {
            if (x[i] > x[0]) {
                maior = x[i];
                mai = i;
            }
        }

        System.out.println("\nMaior elemento: Vetor [" + mai + "] = " + maior);

        menor = x[0];

        for (int i = 0; i < tam; i++) {
            if (x[i] < x[0]) {
                menor = x[i];
                mei = i;
            }
        }

        System.out.println("Menor elemento: Vetor [" + mei + "] = " + menor);

        for (int i = 0; i < tam; i++) {
            soma = soma + x[i];
        }

        media = soma / 6;

        System.out.println("\nSoma dos vetores: " + soma);
        System.out.println("Media dos vetores: " + media + "\n");

        for (int i = 0; i < tam; i++) {
            System.out.println("Vetor [" + i + "] = " + x[i]);
        }
    }
}