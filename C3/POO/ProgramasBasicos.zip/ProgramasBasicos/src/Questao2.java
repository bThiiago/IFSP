
import java.util.Scanner;

/**
 *
 * @author Thiiago
 */

public class Questao2 {

    public static void main(String[] args) {

        int tam = 5;
        int mul;
        int[] x;
        int[] vet = new int[100];
        int[] y;
        int[] vet2 = new int[100];

        Scanner ler = new Scanner(System.in);

        x = new int[tam];
        y = new int[tam];

        for (int i = 0; i < tam; i++) {
            System.out.print("Digite o valor do primeiro vetor [" + i + "]: ");
            x[i] = ler.nextInt();
        }

        System.out.println("\n");

        for (int i = 0; i < tam; i++) {
            System.out.print("Digite o valor do segundo vetor [" + i + "]: ");
            y[i] = ler.nextInt();
        }

        System.out.println("\n");

        for (int i = 0; i < tam; i++) {
            mul = 0;
            mul = x[i] * y[i];
            System.out.println("Vetor1[" + i + "] * Vetor2[" + i + "] = " + mul);
        }

        System.out.println("\n");
    }
}