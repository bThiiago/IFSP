
import java.util.Scanner;

/**
 *
 * @author Thiiago
 */

public class Questao3 {

    public static void main(String[] args) {

        int maior;
        int mai = 0;
        int soma = 0;
        int tam = 8;
        int[] x;
        int[] vet = new int[100];

        Scanner ler = new Scanner(System.in);

        x = new int[tam];

        for (int i = 0; i < tam; i++) {
            System.out.print("Digite o valor do vetor [" + i + "]: ");
            x[i] = ler.nextInt();
        }

        for (int i = 0; i < tam; i++) {
            soma = soma + x[i];
        }

        System.out.println("\nSoma dos vetores: " + soma);

        maior = x[0];

        for (int i = 0; i < tam; i++) {
            if (x[i] > x[0]) {
                maior = x[i];
                mai = i;
            }
        }

        System.out.println("\nMaior elemento: " + maior);
        System.out.println("Posicao: Vetor [" + mai + "]\n");

    }
}