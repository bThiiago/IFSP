CREATE DATABASE comercio;
USE comercio;

CREATE TABLE Cliente (
    codigo INT PRIMARY KEY NOT NULL,,
    nome VARCHAR(80),
    cpf VARCHAR(15),
    endereco VARCHAR(80),
    cidade VARCHAR(40),
    estado VARCHAR(20),
    telefone VARCHAR(20)
);

CREATE TABLE Venda (
    nrNotaFiscal INT PRIMARY KEY,
    valorPago DOUBLE NOT NULL,
    desconto DOUBLE,
    dataVenda VARCHAR(10),
    formaPgto VARCHAR(30)
);

CREATE TABLE Produto (
    codigo INT PRIMARY KEY NOT NULL,,
    descricao VARCHAR(80) NOT NULL,
    preco DOUBLE NOT NULL,,
    quantidadeEstoque INT
);