
package Views;

/**
 *
 * @author Thiiago
 */

public class Principal {
    
    public static void main(String[] args) {

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            System.out.println(ex.toString());
            System.exit(0);
        }
        
        TelaPrincipal tela = new TelaPrincipal();
        tela.setVisible(true);
    }
    
}
