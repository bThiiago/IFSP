
package Controllers;

import Exceptions.NotExistException;
import Models.Cliente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Thiiago
 */

public class ClienteController {
    
    public void include(Cliente c) throws SQLException {
        Connection conexao = ConnectionController.getConexao();

        String comandoSQL = "INSERT INTO Cliente (codigo, nome, cpf, endereco, cidade, estado, telefone) VALUES (?,?,?,?,?,?,?)";

        PreparedStatement execSQL;
        execSQL = conexao.prepareStatement(comandoSQL);

        execSQL.setInt(1, c.getCodigo());
        execSQL.setString(2, c.getNome());
        execSQL.setString(3, c.getCpf());
        execSQL.setString(4, c.getEndereco());
        execSQL.setString(5, c.getCidade());
        execSQL.setString(6, c.getEstado());
        execSQL.setString(7, c.getTelefone());

        execSQL.executeUpdate();
        conexao.commit();
        execSQL.close();
        conexao.close();
    }

    public void delete(Cliente c) throws SQLException, NotExistException {
        Connection conexao = ConnectionController.getConexao();

        String comandoSQL = ("DELETE FROM Cliente WHERE codigo = ?;");

        PreparedStatement execSQL;
        execSQL = conexao.prepareStatement(comandoSQL);

        execSQL.setInt(1, c.getCodigo());

        execSQL.executeUpdate();
        conexao.commit();
        execSQL.close();
        conexao.close();
    }

    public List<Cliente> list() throws SQLException {

        ArrayList<Cliente> listaclientes = new ArrayList<>();

        Connection conexao = ConnectionController.getConexao();
        String comandoSQL = "SELECT * FROM Cliente";

        PreparedStatement execSQL;
        execSQL = conexao.prepareStatement(comandoSQL);
        ResultSet resultadoConsulta;
        resultadoConsulta = execSQL.executeQuery();

        Cliente c;

        while (resultadoConsulta.next()) {
            c = new Cliente();
            c.setCodigo(resultadoConsulta.getInt("codigo"));
            c.setNome(resultadoConsulta.getString("nome"));
            c.setCpf(resultadoConsulta.getString("cpf"));
            c.setEndereco(resultadoConsulta.getString("endereco"));
            c.setCidade(resultadoConsulta.getString("cidade"));
            c.setEstado(resultadoConsulta.getString("estado"));
            c.setTelefone(resultadoConsulta.getString("telefone"));

            listaclientes.add(c);
        }
        return listaclientes;
    }

    public void modify(Cliente c) throws SQLException, NotExistException {
        Connection conexao = ConnectionController.getConexao();

        String comandoSQL = ("UPDATE Cliente SET nome = ?, cpf = ?, endereco = ?, cidade = ?, estado = ?, telefone = ? WHERE codigo = ?");

        PreparedStatement execSQL;
        execSQL = conexao.prepareStatement(comandoSQL);

        execSQL.setString(1, c.getNome());
        execSQL.setString(2, c.getCpf());
        execSQL.setString(3, c.getEndereco());
        execSQL.setString(4, c.getCidade());
        execSQL.setString(5, c.getEstado());
        execSQL.setString(6, c.getTelefone());
        execSQL.setInt(7, c.getCodigo());

        execSQL.executeUpdate();
        conexao.commit();
        execSQL.close();
        conexao.close();
    }

    public Cliente search(int codigoCliente) throws SQLException, NotExistException {
        Cliente c = null;

        Connection conexao = ConnectionController.getConexao();

        String comandoSQL = "SELECT * FROM Cliente WHERE codigo = ?";

        PreparedStatement execSQL;
        execSQL = conexao.prepareStatement(comandoSQL);

        execSQL.setInt(1, codigoCliente);

        ResultSet resultado;
        resultado = execSQL.executeQuery();
        resultado.last();

        if (resultado.getRow() > 0) {
            c = new Cliente();
            c.setCodigo(codigoCliente);
            c.setNome(resultado.getString("nome"));
            c.setCpf(resultado.getString("cpf"));
            c.setEndereco(resultado.getString("endereco"));
            c.setCidade(resultado.getString("cidade"));
            c.setEstado(resultado.getString("estado"));
            c.setTelefone(resultado.getString("telefone"));
        } else {
            throw new NotExistException("Este cliente não existe.");
        }
        
        execSQL.close();
        conexao.close();

        return c;
    }
    
}