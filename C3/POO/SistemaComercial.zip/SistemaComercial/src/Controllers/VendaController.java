
package Controllers;

import Exceptions.NotExistException;
import Models.Venda;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Thiiago
 */

public class VendaController {
    
     public void include(Venda v) throws SQLException {
        Connection conexao = ConnectionController.getConexao();

        String comandoSQL = "INSERT INTO Venda (nrNotaFiscal, valorPago, desconto, dataVenda, formaPagto, cliente, codigo) VALUES (?,?,?,?,?,?,?)";

        PreparedStatement execSQL;
        execSQL = conexao.prepareStatement(comandoSQL);

        execSQL.setInt(1, v.getNrNotaFiscal());
        execSQL.setDouble(2, v.getValorPago());
        execSQL.setDouble(3, v.getDesconto());
        execSQL.setString(4, v.getDataVenda());
        execSQL.setString(5, v.getFormaPgto());
        execSQL.setString(6, v.getClienteCpf());
        execSQL.setInt(7, v.getProdutoCod());

        execSQL.executeUpdate();
        conexao.commit();
        execSQL.close();
        conexao.close();
    }

    public List<Venda> list() throws SQLException {
        ArrayList<Venda> listavendas = new ArrayList<>();

        Connection conexao = ConnectionController.getConexao();
        
        String comandoSQL = "SELECT * FROM Venda";

        PreparedStatement execSQL;
        execSQL = conexao.prepareStatement(comandoSQL);
        ResultSet resultadoConsulta;
        resultadoConsulta = execSQL.executeQuery();

        Venda v;

        while (resultadoConsulta.next()) {
            v = new Venda();
            v.setNrNotaFiscal(resultadoConsulta.getInt("numeroNota"));
            v.setValorPago(resultadoConsulta.getDouble("valorPago"));
            v.setDesconto(resultadoConsulta.getDouble("desconto"));
            v.setDataVenda(resultadoConsulta.getString("dataVenda"));
            v.setFormaPgto(resultadoConsulta.getString("formaPgto"));
            v.setClienteCpf(resultadoConsulta.getString("setClienteCpf"));
            v.setProdutoCod(resultadoConsulta.getInt("setProdutoCod"));

            listavendas.add(v);
        }
        
        return listavendas;
    }

    public void modify(Venda v) throws SQLException, NotExistException {
        Connection conexao = ConnectionController.getConexao();
        
        String comandoSQL = ("UPDATE Venda SET valorPago = ?, desconto = ?, dataVenda = ?, formaPgto = ?, clienteCpf = ?, produtoCod = ? WHERE nrNotaFiscal = ?");

        PreparedStatement execSQL;
        execSQL = conexao.prepareStatement(comandoSQL);

        execSQL.setDouble(1, v.getValorPago());
        execSQL.setDouble(2, v.getDesconto());
        execSQL.setString(3, v.getDataVenda());
        execSQL.setString(4, v.getFormaPgto());
        execSQL.setString(5, v.getClienteCpf());
        execSQL.setInt(6, v.getProdutoCod());
        execSQL.setInt(7, v.getNrNotaFiscal());

        execSQL.executeUpdate();
        conexao.commit();
        execSQL.close();
        conexao.close();
    }

    public void delete(Venda v) throws SQLException, NotExistException {
        Connection conexao = ConnectionController.getConexao();

        String comandoSQL = ("DELETE FROM Venda WHERE nrNotaFiscal = ?;");

        PreparedStatement execSQL;
        execSQL = conexao.prepareStatement(comandoSQL);

        execSQL.setInt(1, v.getNrNotaFiscal());

        execSQL.executeUpdate();
        conexao.commit();
        execSQL.close();
        conexao.close();
    }
    
}
