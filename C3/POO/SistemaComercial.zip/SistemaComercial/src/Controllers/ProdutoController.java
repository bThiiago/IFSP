
package Controllers;

import Exceptions.NotExistException;
import Models.Produto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Thiiago
 */

public class ProdutoController {
    
    public void include(Produto p) throws SQLException {
        Connection conexao = ConnectionController.getConexao();

        String comandoSQL = "INSERT INTO Produto (codigo, descricao, preco, quantidadeEstoque) VALUES (?,?,?,?)";

        PreparedStatement execSQL;
        execSQL = conexao.prepareStatement(comandoSQL);

        execSQL.setInt(1, p.getCodigo());
        execSQL.setString(2, p.getDescricao());
        execSQL.setDouble(3, p.getPreco());
        execSQL.setInt(4, p.getQuantidadeEstoque());

        execSQL.executeUpdate();
        conexao.commit();
        execSQL.close();
        conexao.close();
    }

    public List<Produto> list() throws SQLException {
        ArrayList<Produto> listaprodutos = new ArrayList<>();

        Connection conexao = ConnectionController.getConexao();
        
        String comandoSQL = "SELECT * FROM Produto";

        PreparedStatement execSQL;
        execSQL = conexao.prepareStatement(comandoSQL);
        ResultSet resultadoConsulta;
        resultadoConsulta = execSQL.executeQuery();

        Produto p;

        while (resultadoConsulta.next()) {
            p = new Produto();
            p.setCodigo(resultadoConsulta.getInt("codigo"));
            p.setDescricao(resultadoConsulta.getString("descricao"));
            p.setPreco(resultadoConsulta.getDouble("preco"));
            p.setQuantidadeEstoque(resultadoConsulta.getInt("quantidadeEstoque"));

            listaprodutos.add(p);
        }
        return listaprodutos;
    }

    public void modify(Produto p) throws SQLException, NotExistException {
        Connection conexao = ConnectionController.getConexao();

        String comandoSQL = ("UPDATE Produto SET descricao = ?, preco = ?, quantidadeEstoque = ? WHERE codigo = ?");

        PreparedStatement execSQL;
        execSQL = conexao.prepareStatement(comandoSQL);

        execSQL.setString(1, p.getDescricao());
        execSQL.setDouble(2, p.getPreco());
        execSQL.setInt(3, p.getQuantidadeEstoque());
        execSQL.setInt(4, p.getCodigo());

        execSQL.executeUpdate();
        conexao.commit();
        execSQL.close();
        conexao.close();
    }

    public void delete(Produto p) throws SQLException, NotExistException {
        Connection conexao = ConnectionController.getConexao();

        String comandoSQL = ("DELETE FROM Produto WHERE codigo = ?;");

        PreparedStatement execSQL;
        execSQL = conexao.prepareStatement(comandoSQL);

        execSQL.setInt(1, p.getCodigo());

        execSQL.executeUpdate();
        conexao.commit();
        execSQL.close();
        conexao.close();
    }
    
}