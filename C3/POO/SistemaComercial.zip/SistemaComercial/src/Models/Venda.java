
package Models;

import java.util.ArrayList;

/**
 *
 * @author Thiiago
 */

public class Venda {
    private int nrNotaFiscal;
    private double valorPago;
    private double desconto;
    private String dataVenda;
    private String formaPgto;
    private String clienteCpf;
    private int produtoCod;
   
    
    public Venda() {
    }

    public Venda(int nrNotaFiscal, double valorPago, double desconto, String dataVenda, String formaPgto, String clienteCpf, int produtoCod) {
        this.nrNotaFiscal = nrNotaFiscal;
        this.valorPago = valorPago;
        this.desconto = desconto;
        this.dataVenda = dataVenda;
        this.formaPgto = formaPgto;
        this.clienteCpf = clienteCpf;
        this.produtoCod = produtoCod;
    }
    
    public int getNrNotaFiscal() {
        return nrNotaFiscal;
    }

    public void setNrNotaFiscal(int nrNotaFiscal) {
        this.nrNotaFiscal = nrNotaFiscal;
    }

    public double getValorPago() {
        return valorPago;
    }

    public void setValorPago(double valorPago) {
        this.valorPago = valorPago;
    }

    public double getDesconto() {
        return desconto;
    }

    public void setDesconto(double desconto) {
        this.desconto = desconto;
    }

    public String getDataVenda() {
        return dataVenda;
    }

    public void setDataVenda(String dataVenda) {
        this.dataVenda = dataVenda;
    }

    public String getFormaPgto() {
        return formaPgto;
    }

    public void setFormaPgto(String formaPgto) {
        this.formaPgto = formaPgto;
    }

    public String getClienteCpf() {
        return clienteCpf;
    }

    public void setClienteCpf(String clienteCpf) {
        this.clienteCpf = clienteCpf;
    }

    public int getProdutoCod() {
        return produtoCod;
    }

    public void setProdutoCod(int produtoCod) {
        this.produtoCod = produtoCod;
    }
    
}
