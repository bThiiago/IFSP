
package Exceptions;

/**
 *
 * @author Thiiago
 */

public class NotExistException extends Exception {
    public NotExistException(String naoEncontrado) {}
}
