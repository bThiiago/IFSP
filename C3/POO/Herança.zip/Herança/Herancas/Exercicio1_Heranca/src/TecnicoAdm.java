
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author franca1
 */
public class TecnicoAdm extends Pessoa {

    private String setor;
    private String cargo;

    public TecnicoAdm() {

    }

    public TecnicoAdm(String prontuario, String nome, String setor, String cargo) {

        super(setor, cargo);
        this.setor = setor;
        this.cargo = cargo;
    }

    @Override
    public void lerDados() {
        super.lerDados();

        Scanner read = new Scanner(System.in);

        System.out.println("digite o setor: ");
        this.setor = read.nextLine();

        System.out.println("Digite o cargo: ");
        this.cargo = read.nextLine();

    }
    
    @Override
    public void apresentaDados(){
        System.out.printf("Tecnico.");
        super.apresentaDados();
        System.out.println("Tecnico: ");
        System.out.println("Setor: " + this.setor);
        System.out.println("Cargo: " + this.cargo);
        System.out.println("");
             
        
    }
}
