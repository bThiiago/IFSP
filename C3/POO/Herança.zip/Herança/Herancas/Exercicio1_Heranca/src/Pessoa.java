
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author franca1
 */
public class Pessoa {

    String prontuario;
    private String nome;

    public Pessoa() {
    }

    public Pessoa(String prontuario, String nome) {

        this.prontuario = prontuario;
        this.nome = nome;

    }

    public void lerDados() {

        Scanner read = new Scanner(System.in);

        System.out.println("Digite o nome: ");
        this.nome = read.nextLine();

        System.out.println("Digite o prontuario: ");
        this.prontuario = read.nextLine();

    }

    public void apresentaDados() {
        System.out.println("");
        System.out.println("Nome: " + this.nome);
        System.out.println("Prontuario: " + this.prontuario);
        

    }
}
