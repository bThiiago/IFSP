
import java.util.ArrayList;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author franca1
 */
public class Principal {

    public static void main(String[] args) {

        ControlaPesoas cp = new ControlaPesoas();

        Scanner read = new Scanner(System.in);

        int op;

        do {
            System.out.println("Menu principal\n");

            System.out.println("1 - Cadastrar Alunos");

            System.out.println("2 - Cadastrar Tecnicos");

            System.out.println("3 - Cadastrar Professores");

            System.out.println("4 - Apresentar Funcionarios ");

            System.out.print("Digite a opção desejada..: ");
            op = read.nextInt();

            System.out.printf("\n");

            switch (op) {
                case 1:
                    cp.cadastraAlunos();
                    break;
                case 2:
                    cp.cadastraTecnico();
                    break;
                case 3:
                    cp.cadastraProfessor();
                    break;
                case 4:
                    cp.apresentaTudo();
                    break;

            }
        } while (op != 0);
    }

}
