
import java.util.ArrayList;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author franca1
 */
public class ControlaPesoas {

    private ArrayList<Pessoa> listapessoa = new ArrayList<>();

    Pessoa pessoa = new Pessoa();
    Aluno alu = new Aluno();
    TecnicoAdm adm = new TecnicoAdm();
    Professor prof = new Professor();

    public void cadastraAlunos() {
        Scanner read = new Scanner(System.in);

        Aluno alu = new Aluno();
        alu.lerDados();
        this.listapessoa.add(alu);

    }

    public void cadastraTecnico() {
        Scanner read = new Scanner(System.in);

        TecnicoAdm adm = new TecnicoAdm();
        adm.lerDados();
        this.listapessoa.add(adm);

    }

    public void cadastraProfessor() {
        Scanner read = new Scanner(System.in);

        Professor prof = new Professor();
        prof.lerDados();
        this.listapessoa.add(prof);

    }

    public void apresentaTudo() {
        for (Pessoa pessoa : listapessoa) {
            pessoa.apresentaDados();

        }
    }

}
