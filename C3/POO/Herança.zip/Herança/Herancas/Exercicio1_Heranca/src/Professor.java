
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author franca1
 */
public class Professor extends Pessoa {

    private String area;
    private String tipoContrato;

    public Professor() {

    }

    public Professor(String prontuario, String nome, String setor, String cargo, String area, String tipoContrato) {

        super(area, tipoContrato);
        this.area = area;
        this.tipoContrato = tipoContrato;
    }

    @Override
    public void lerDados() {

        super.lerDados();

        Scanner read = new Scanner(System.in);

        System.out.println("Digite a area: ");
        area = read.nextLine();

        System.out.println("Digite o tipo de contrato: ");
        tipoContrato = read.nextLine();

    }

    @Override
    public void apresentaDados() {
        System.out.printf("Professor.");
        super.apresentaDados();
        System.out.println("Professor: ");
        System.out.println("Area: " + this.area);
        System.out.println("Tipo de contrato: " + this.tipoContrato);
        System.out.println("");

    }
}
