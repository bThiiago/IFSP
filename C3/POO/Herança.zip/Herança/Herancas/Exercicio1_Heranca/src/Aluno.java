
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author franca1
 */
public class Aluno extends Pessoa {

    private String curso;
    private String semestreAno;

    public Aluno() {

    }

    public Aluno(String prontuario, String nome, String curso, String semestreAno) {

        super(prontuario, nome);
        this.curso = curso;
        this.semestreAno = semestreAno;
    }

    @Override
    public void lerDados() {

        super.lerDados();

        Scanner read = new Scanner(System.in);

        System.out.println("Digite o nome do curso: ");
        this.curso = read.nextLine();

        System.out.println("Digite o semestre: ");
        this.semestreAno = read.nextLine();

    }

    @Override

    public void apresentaDados() {

        System.out.printf("Aluno.");
        super.apresentaDados();

        System.out.println("Curso: " + this.curso);
        System.out.println("Semestre: " + this.semestreAno);
        System.out.println("");

    }

}
