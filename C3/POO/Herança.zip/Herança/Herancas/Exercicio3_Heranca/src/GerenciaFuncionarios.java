
import java.util.ArrayList;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author franca1
 */
public class GerenciaFuncionarios {

    private ArrayList<Funcionario> listafuncionario = new ArrayList<>();

    public void cadastraFuncionarioComum() {

        FuncionarioComum funcom = new FuncionarioComum();
        funcom.lerDados();
        listafuncionario.add(funcom);

    }

    public void cadastraFuncionarioComisado() {

        FuncionarioComissado funcomi = new FuncionarioComissado();

        funcomi.lerDados();

        listafuncionario.add(funcomi);

    }

    public void cadastraFuncionarioDiarista() {

        FuncionarioDiarista fund = new FuncionarioDiarista();

        fund.lerDados();

        listafuncionario.add(fund);

    }

    public void apresentaFuncionarios() {
        for (Funcionario func : listafuncionario) {

            func.apresentaDados();

        }

    }

    public void apresentaTotalIR() {

        float total = 0;

        for (Funcionario func : listafuncionario) {
            total = total + func.getIR();
        }
        
        System.out.printf("\ntotal IR;.......: %.2f\n", total);

    }

    public void apresentaTotalINSS() {

        float total = 0;

        for (Funcionario func : listafuncionario) {
            total = total + func.getINSS();
        }
        
        System.out.printf("\ntotal INSS;.......: %.2f\n", total);

    }

    public void apresentaTotalSalarioLiquido() {

        float total = 0;

        for (Funcionario func : listafuncionario) {
            total = total + func.getSalarioLiquido();
        }
System.out.printf("\ntotal salario liquido;.......: %.2f\n", total);
    }

}
