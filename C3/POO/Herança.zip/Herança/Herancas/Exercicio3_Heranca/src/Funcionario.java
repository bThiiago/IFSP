
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author franca1
 */
public class Funcionario {

    int numero_registro;
    private String nome;
    private String cargo;

    public Funcionario() {
    }

    public Funcionario(int numero_registro, String nome, String cargo) {

        this.numero_registro = numero_registro;

        this.nome = nome;

        this.cargo = cargo;

    }

    public void lerDados() {

        Scanner read = new Scanner(System.in);

        System.out.println("Digite o numero de registro: ");
        this.numero_registro = read.nextInt();

        System.out.println("digite o Nome: ");
        read.nextLine();
        this.nome = read.nextLine();

        System.out.println("Digite o cargo ocupado: ");
        this.cargo = read.nextLine();

    }

    public void apresentaDados() {

        System.out.println("");
        System.out.println("Numero de registro: " + this.numero_registro);
        System.out.println("Nome: " + this.nome);
        System.out.println("Cargo: " + this.cargo);

    }

    public float getIR() {

        return 1;
    }

    public float getSalarioLiquido() {

        return 1;
    }

    public float getINSS() {

        return 1;
    }

    public float getSalarioBruto() {

        return 1;
    }

    public int getNumero_registro() {
        return numero_registro;
    }

    public String getNome() {
        return nome;
    }

    public String getCargo() {
        return cargo;
    }

}
