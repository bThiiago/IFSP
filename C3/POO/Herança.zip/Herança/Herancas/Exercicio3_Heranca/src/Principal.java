
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author franca1
 */
public class Principal {

    public static void main(String[] args) {

        GerenciaFuncionarios gf = new GerenciaFuncionarios();

        Scanner read = new Scanner(System.in);

        int op;

        do {
            System.out.println("Menu principal\n");

            System.out.println("1 - Cadastrar Funcionarios Comuns");

            System.out.println("2 - Cadastrar Funcionarios Comissados");

            System.out.println("3 - Cadastrar Funcionario Diarista");

            System.out.println("4 - Apresenta funcionarios ");

            System.out.println("5 - Total IR ");

            System.out.println("6 - Total de INSS");

            System.out.println("7 - Total Salario Liquido");

            System.out.print("Digite a opção desejada..: ");
            op = read.nextInt();

            System.out.printf("\n");

            switch (op) {
                case 1:
                    gf.cadastraFuncionarioComum();
                    break;
                case 2:
                    gf.cadastraFuncionarioComisado();
                    break;
                case 3:
                    gf.cadastraFuncionarioDiarista();
                    break;
                case 4:
                    gf.apresentaFuncionarios();
                    break;

                case 5:
                    gf.apresentaTotalIR();
                    break;

                case 6:
                    gf.apresentaTotalINSS();
                    break;

                case 7:
                    gf.apresentaTotalSalarioLiquido();
                    break;

            }
        } while (op != 0);
    }

}
