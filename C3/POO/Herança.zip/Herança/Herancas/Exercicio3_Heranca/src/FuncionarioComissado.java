
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author franca1
 */
public class FuncionarioComissado extends Funcionario {

    private float valorVendas;
    private float salario;
    private float percentualComissao;

    public FuncionarioComissado() {

    }

    public FuncionarioComissado(int numero_registro, String nome, String cargo,
            float valorVendas, float salario, float percentualComissao) {

        super(numero_registro, nome, cargo);

        this.percentualComissao = percentualComissao;
        this.salario = salario;
        this.valorVendas = valorVendas;

    }

    @Override
    public void lerDados() {
        Scanner read = new Scanner(System.in);
        super.lerDados();

        System.out.println("Digite o valor em vendas: ");
        this.valorVendas = read.nextFloat();

        System.out.println("Digite o seu salario: ");
        this.salario = read.nextFloat();

        System.out.println("Digite o seu percentual de comissao: ");
        this.percentualComissao = read.nextFloat();

    }

    @Override
    public void apresentaDados() {
        System.out.println("Funcionario comissado.");
        super.apresentaDados();
        System.out.println("Valor em vendas: " + this.valorVendas);
        System.out.println("salario: " + this.salario);
        System.out.println("Percentual de comissao: " + this.percentualComissao);
        System.out.println("SalarioBruto: " + this.getSalarioBruto());
        System.out.println("Salario liquido: " + this.getSalarioLiquido());
        System.out.println("Valor INSS: " + this.getINSS());
        System.out.println("Valor IR: " + this.getIR());
        System.out.println("");

    }

    @Override

    public float getSalarioBruto() {

        float salarioComissionado = 0;

        salarioComissionado = (this.getValorVendas() * this.getPercentualComissao() / 100) + this.getSalario();

        return salarioComissionado;
    }

    @Override
    public float getINSS() {

        float valorINSS = 0;

        if (this.getSalarioBruto() <= 2000) {

            valorINSS = (float) (this.getSalarioBruto() * 0.08);

        } else if (this.getSalarioBruto() >= 2000) {
            valorINSS = (float) (this.getSalarioBruto() * 0.011);

        }
        return valorINSS;
    }

    @Override
    public float getIR() {
        float valorIR = 0;

        if (this.getSalarioBruto() <= 2000) {
            valorIR = 0;

        } else if (this.getSalarioBruto() >= 2000 && this.getSalarioBruto() <= 4000) {
            valorIR = (float) (this.getSalarioBruto() * 0.15);
        } else if (this.getSalarioBruto() > 4000) {
            valorIR = (float) (this.getSalarioBruto() * 0.25);

        }
        return valorIR;
    }

    @Override
    public float getSalarioLiquido() {

        float valorSalarioliquido = 0;

        valorSalarioliquido = this.getSalarioBruto() - this.getIR() - this.getINSS();

        return valorSalarioliquido;
    }

    public float getValorVendas() {
        return valorVendas;
    }

    public float getSalario() {
        return salario;
    }

    public float getPercentualComissao() {
        return percentualComissao;
    }

}
