
import java.util.ArrayList;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author franca1
 */
public class Principal {

    public static void main(String[] args) {

        GerenciaConta gc = new GerenciaConta();

        Scanner read = new Scanner(System.in);

        int op;

        do {
            System.out.println("Menu principal\n");

            System.out.println("1 - Cadastrar Conta");

            System.out.println("2 - Cadastrar Conta Poupanca");

            System.out.println("3 - Cadastrar Conta especial");

            System.out.println("4 - Apresentar Contas: ");

            System.out.println("5 - Depositar ");

            System.out.println("6 - Sacar ");

            System.out.println("7 - Transferir ");

            System.out.print("Digite a opção desejada..: ");
            op = read.nextInt();

            System.out.printf("\n");

            switch (op) {
                case 1:
                    gc.CadastraConta();
                    break;
                case 2:
                    gc.CadastraContaPoupanca();
                    break;
                case 3:
                    gc.CadastraContaEspecial();
                    break;
                case 4:
                    gc.apresentaDados();
                    break;
                case 5:
                    gc.deposito();
                    break;
                case 6:
                    gc.saque();
                    break;
                case 7:
                    gc.transferir();
                    break;

            }
        } while (op != 0);
    }

}
