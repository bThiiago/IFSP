
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author franca1
 */
public class Conta {

    private int numAgencia;
    private int numConta;
    private String data;
    private float saldo;
    private String nome;
    private String email;

    public Conta() {

    }

    public Conta(int numAgencia, int numConta, String data, float saldo, String nome, String email) {

        this.numAgencia = numAgencia;
        this.numConta = numConta;
        this.data = data;
        this.saldo = saldo;
        this.email = email;
        this.nome = nome;

    }

    public void lerDados() {

        Scanner read = new Scanner(System.in);

        System.out.println("Digite o numero da agencia: ");
        this.numAgencia = read.nextInt();

        System.out.println("DIgite o numero da conta: ");
        this.numConta = read.nextInt();

        System.out.println("Digite a data: ");
        read.nextLine();
        this.data = read.nextLine();

        System.out.println("Digite o saldo: ");
        this.saldo = read.nextFloat();

        System.out.println("Digite o seu nome: ");
        read.nextLine();
        this.nome = read.nextLine();

        System.out.println("Digite o seu Email: ");

        this.email = read.nextLine();

    }

    public void ApresentaDados() {

        System.out.println("");
        System.out.println("Numero da agencia: " + this.numAgencia);
        System.out.println("Numero da conta: " + this.numConta);
        System.out.println("Data: " + this.data);
        System.out.println("Saldo: " + this.saldo);
        System.out.println("Nome: " + this.nome);
        System.out.println("Email: " + this.email);

    }

    public int getNumAgencia() {
        return numAgencia;
    }

    public int getNumConta() {
        return numConta;
    }

    public String getData() {
        return data;
    }

    public float getSaldo() {
        return saldo;
    }

    public String getNome() {
        return nome;
    }

    public String getEmail() {
        return email;
    }

    public void setNumAgencia(int numAgencia) {
        this.numAgencia = numAgencia;
    }

    public void setNumConta(int numConta) {
        this.numConta = numConta;
    }

    public void setData(String data) {
        this.data = data;
    }

    public void setSaldo(float saldo) {
        this.saldo = saldo;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void deposito(float valordeposito) {

        this.saldo += valordeposito;

    }

    public boolean sacar(float valorSacar) {
        if (this.saldo > valorSacar) {
            this.saldo -= valorSacar;
            return true;
        } else {
            return false;
        }
    }

    public boolean transferircontas(Conta contaTranferir, float valorTrans) {

        boolean conseguiuSacar = this.sacar(valorTrans);
        if (conseguiuSacar) {
            contaTranferir.deposito(valorTrans);
        }
        return conseguiuSacar;
    }

}
