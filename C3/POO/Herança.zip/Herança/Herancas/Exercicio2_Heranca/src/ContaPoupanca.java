
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author franca1
 */
public class ContaPoupanca extends Conta {

    private float percentual;

    public ContaPoupanca() {

    }

    public ContaPoupanca(int numAgencia, int numConta, String data, float saldo, String nome, String email) {

        super(numAgencia, numConta, data, saldo, nome, email);

        this.percentual = percentual;
    }

    @Override
    public void lerDados() {

        Scanner read = new Scanner(System.in);

        super.lerDados();
        System.out.println("Digite o percentual de remuneracao: ");
        this.percentual = read.nextFloat();
    }

    @Override
    public void ApresentaDados() {

        System.out.println("Conta Poupanca");
        super.ApresentaDados();

        System.out.println("");
        System.out.println("Percentual de remuneracao: " + this.percentual);
    }

    public void aplicaJuros() {

        float aplicar = (this.getSaldo() * this.percentual / 100) + this.getSaldo();

        this.setSaldo(aplicar);
    }

}
