
import java.util.Scanner;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author franca1
 */
public class GerenciaConta {

    private ArrayList<Conta> listaconta = new ArrayList<>();

    public Conta buscaconta(int NumAgencia, int NumConta) {

        Conta contaCorrente = null;

        for (Conta cc : listaconta) {

            if (cc.getNumAgencia() == NumAgencia && cc.getNumConta() == NumConta) {
                contaCorrente = cc;
            }
        }

        return contaCorrente;

    }

    public void CadastraConta() {

        Conta contaCorrente = new Conta();

        contaCorrente.lerDados();

        listaconta.add(contaCorrente);

    }

    public void CadastraContaPoupanca() {

        ContaPoupanca contaPoupanca = new ContaPoupanca();

        contaPoupanca.lerDados();

        listaconta.add(contaPoupanca);

    }

    public void CadastraContaEspecial() {

        ContaEspecial contaEspecial = new ContaEspecial();

        contaEspecial.lerDados();

        listaconta.add(contaEspecial);

    }

    public void apresentaDados() {
        for (Conta cont : listaconta) {

            cont.ApresentaDados();
        }
    }

    public void deposito() {

        int agenciaorig, contaorig;
        float valor;
        Conta contaOrigem;

        Scanner read = new Scanner(System.in);

        System.out.println("Digite o numero da agencia: ");
        agenciaorig = read.nextInt();

        System.out.println("Digite o numero da conta: ");
        contaorig = read.nextInt();

        contaOrigem = buscaconta(agenciaorig, contaorig);

        if (contaOrigem == null) {

            System.out.println("A conta nao foi cadastrada");

        } else {

            System.out.println("Digite o valor para o deposito: ");
            valor = read.nextFloat();

            contaOrigem.deposito(valor);

        }

    }

    public void saque() {

        int agenciaorig, contaorig;
        float valor;
        Conta contaOrigem;

        Scanner read = new Scanner(System.in);

        System.out.println("Digite o numero da agencia: ");
        agenciaorig = read.nextInt();

        System.out.println("Digite o numero da conta: ");
        contaorig = read.nextInt();

        contaOrigem = buscaconta(agenciaorig, contaorig);

        if (contaOrigem == null) {

            System.out.println("A conta nao foi cadastrada");

        } else {

            System.out.println("Digite o valor para sacar");
            valor = read.nextFloat();

            contaOrigem.sacar(valor);
        }

    }

    public void aplicaJurosPoupanca() {

        for (Conta cont : listaconta) {
            if (cont instanceof ContaPoupanca) {

                ((ContaPoupanca) cont).aplicaJuros();

            }
        }
    }

    public void aplicaJurosEspecial() {

        for (Conta cont : listaconta) {
            if (cont instanceof ContaEspecial) {

                ((ContaEspecial) cont).aplicaJuroscontaEspecial();

            }
        }
    }

    public void transferir() {

        int agenciaorig, contaorig, contadestino, agenciadestino;

        Conta contaOrigem;

        Conta contaDestino;

        Scanner read = new Scanner(System.in);

        System.out.println("Digite o numero da agencia: ");
        agenciaorig = read.nextInt();

        System.out.println("Digite o numero da conta: ");
        contaorig = read.nextInt();

        contaOrigem = buscaconta(agenciaorig, contaorig);

        if (contaOrigem == null) {
            System.out.println("A conta nao foi cadastrada");
        } else {
            System.out.println("Digite o numero da agencia que deseja fazer a transferencia: ");
            agenciadestino = read.nextInt();
            System.out.println("Digite o numero da conta que deseja fazer a transferencia: ");
            contadestino = read.nextInt();

            contaDestino = buscaconta(agenciadestino, contadestino);

            if (contaDestino == null) {
                System.out.println("esta conta nao e possivel fazer a transferencia");

            } else {

                System.out.println("Digite o valor para transferencia: ");
                float valor = read.nextFloat();

                if (contaOrigem.sacar(valor)) {

                    contaDestino.deposito(valor);
                    System.out.println("Sucesso ");

                } else {
                    System.out.println("nao foi possivel transferir");
                }
            }
        }

    }

}
