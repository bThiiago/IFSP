
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Thiiago
 */

public class Principal {
    
    public static void main(String[] args) {
    
    ArrayList<Conta> listaContas = new ArrayList<>();
    
    Scanner l = new Scanner(System.in);
    String opcao;
    
    boolean execute = true;
                
        while (execute) {
            System.out.println("\n(!) Abrir nova conta (!)");
            System.out.println(" A - Abrir conta corrente");
            System.out.println(" B - Abrir conta corrente especial");
            System.out.println(" C - Abrir conta poupança");
            System.out.println("(!) Abrir nova conta (!)\n");
            System.out.println(" D - Dados da minha conta\n");
            
            System.out.println(" X - Sair");
            System.out.print("\nSelecione a opção: ");
            opcao = l.nextLine();

            if (opcao.equalsIgnoreCase("a")) {
                ContaCorrente cc = new ContaCorrente();
                listaContas.add(cc);
                cc.Ler();
            } else if (opcao.equalsIgnoreCase("b")) {
                ContaCorrenteEspecial cce = new ContaCorrenteEspecial();
                listaContas.add(cce);
                cce.Ler();
            } else if (opcao.equalsIgnoreCase("c")) {
                ContaPoupanca cp = new ContaPoupanca();
                listaContas.add(cp);
                cp.Ler();
            } else if (opcao.equalsIgnoreCase("1")) {

            } else if (opcao.equalsIgnoreCase("2")) {

            } else if (opcao.equalsIgnoreCase("x")) {
                execute = false;
            } else {
                System.out.println("\nOpção Inválida!! \n");
            }
        }
    }
}