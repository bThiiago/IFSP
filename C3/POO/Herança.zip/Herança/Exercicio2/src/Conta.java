
import java.util.Scanner;

/**
 *
 * @author Thiiago
 */

public abstract class Conta {
    private int nrAgencia;
    private int nrConta;
    private String nomeProprietario;
    private String email;
    private String telefone;
    private String dataAbertura;
    private double saldo;
    
    public Conta(){}

    public Conta(int nrAgencia, int nrConta, String nomeProprietario, String email, String telefone,
                       String dataAbertura, double saldo)
    {
        this.nrAgencia = nrAgencia;
        this.nrConta = nrConta;
        this.nomeProprietario = nomeProprietario;
        this.email = email;
        this.telefone = telefone;
        this.dataAbertura = dataAbertura;
        this.saldo = saldo;
    }
    
    public void Ler()
    {
        Scanner ler = new Scanner(System.in);

        System.out.print ("\nNumero Agencia...: ");
        this.nrAgencia = ler.nextInt();
        System.out.print ("Numero Conta.....: ");
        this.nrConta = ler.nextInt();
        System.out.print ("Proprietario.....: ");
        this.nomeProprietario = ler.nextLine();
        System.out.print ("Email............: ");
        this.email = ler.nextLine();
        System.out.print ("Telefone.........: ");
        this.telefone = ler.nextLine();
        System.out.print ("Data Abertura....: ");
        this.dataAbertura = ler.nextLine();
        System.out.print ("Saldo da Conta...: ");
        this.saldo = ler.nextDouble();
    }
    
    public void Imprimir()
    {
        System.out.println ("\nNumero Agencia...: " + this.nrAgencia);
        System.out.println ("Numero Conta.....: " + this.nrConta);
        System.out.println ("Proprietario.....: " + this.nomeProprietario);
        System.out.println ("Email............: " + this.email);
        System.out.println ("Telefone.........: " + this.telefone);
        System.out.println ("Data Abertura....: " + this.dataAbertura);
        System.out.println ("Saldo da Conta...: " + this.saldo);
    }

    public abstract double depositarValor();
    public abstract double sacarValor();
    public abstract double transferirValor();
    public double retornarSaldo()
    {
        return this.saldo;
    }
            
}
