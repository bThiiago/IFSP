
/**
 *
 * @author Thiiago
 */

public class ContaCorrenteEspecial extends Conta {
    
    public ContaCorrenteEspecial(){}
    
    public ContaCorrenteEspecial(int nrAgencia, int nrConta, String nomeProprietario, String email, String telefone,
                       String dataAbertura, double saldo)
    {
        super(nrAgencia, nrConta, nomeProprietario, email, telefone, dataAbertura, saldo);
    }
    
    @Override
    public void Ler()
    {
        super.Ler();
    }
    
    @Override
    public void Imprimir()
    {
        super.Imprimir();
    }
    
    @Override
    public double depositarValor()
    {
        double deposito = 0;
        
    return deposito;
    }
    
    @Override
    public double sacarValor()
    {
        double valor = 0;
        
    return valor;
    }
    
    @Override
    public double transferirValor()
    {
        double transferir = 0;
        
    return transferir;
    }
    
    @Override
    public double retornarSaldo()
    {
     return super.retornarSaldo();   
    }
}
