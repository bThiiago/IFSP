
import java.util.Scanner;

/**
 *
 * @author Thiiago
 */

public class Pessoa {
    
    private String prontuario;
    private String nome;
    
    public Pessoa(){}
    
    public Pessoa(String prontuario, String nome)
    {
        this.nome = nome;
        this.prontuario = prontuario;
        
    }
    
    public void ler()
    {
        Scanner ler = new Scanner(System.in);
        
        System.out.print("\nProntuario...: ");
        this.prontuario = ler.nextLine();
        System.out.print("Nome.........: ");
        this.nome = ler.nextLine();

    }
    
    public void imprimir()
    {
        System.out.println("\nProntuario...: " +  this.prontuario);
        System.out.println("Nome.........: " + this.nome);
    }
}
