
import java.util.Scanner;

/**
 *
 * @author Thiiago
 */

public class Aluno extends Pessoa {
    
    private String curso;
    private String semestre;
    
    public Aluno(){}
    
    public Aluno(String prontuario, String nome, String curso, String semestre)
    {
        super(prontuario, nome);
        this.curso = curso;
        this.semestre = semestre;
    }
    
    @Override
    public void ler()
    {
        super.ler();
        
        Scanner ler = new Scanner(System.in);
        
        System.out.print("Curso........: ");
        this.curso = ler.nextLine();        
        System.out.print("Semestre.....: ");
        this.semestre = ler.nextLine();                  
        
    }
       
    @Override
    public void imprimir()
    {
        super.imprimir();
        
        System.out.println("Curso........: " +  this.curso);
        System.out.println("Semestre.....: " +  this.semestre);      
    }        
}
