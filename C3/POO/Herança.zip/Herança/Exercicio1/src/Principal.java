
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Thiiago
 */

public class Principal {
    
    public static void main(String[] args) {

    ArrayList<Pessoa> listaPessoas = new ArrayList<>();
        
    Scanner ler = new Scanner(System.in);
    String opcao;
    int confirm1 = 0;
    int confirm2 = 0;
    int confirm3 = 0;

    boolean execute = true;
    
        while (execute) {
            System.out.println("\n1 - Cadastrar classe");
            System.out.println("    a) Aluno");
            System.out.println("    b) Professor");
            System.out.println("    c) Tecnico");
            System.out.println("2 - Imprimir classe");
            System.out.println("    d) Aluno");
            System.out.println("    e) Professor");
            System.out.println("    f) Tecnico");
            System.out.println("3 - Listar tudo");
            System.out.println("X - Sair");
            System.out.print("Selecione a opção: ");
            opcao = ler.nextLine();

            if (opcao.equalsIgnoreCase("a")) {
                Aluno a = new Aluno();
                listaPessoas.add(a);
                a.ler();
                confirm1 = 1;
            } else if (opcao.equalsIgnoreCase("b")) {
                Professor p = new Professor();
                listaPessoas.add(p);
                p.ler();
                confirm2 = 1;
            } else if (opcao.equalsIgnoreCase("c")) {
                TecnicoAdm ta = new TecnicoAdm();
                listaPessoas.add(ta);
                ta.ler();
                confirm3 = 1;
            } else if (opcao.equalsIgnoreCase("d")) {
                if (confirm1 == 1){
                    for ( Pessoa pe : listaPessoas ){ 
                        if ( pe instanceof Aluno ) 
                        { 
                            pe.imprimir();
                        }
                    }
                } else {
                    System.out.println("\nNão existe um aluno cadastrado!");
                }
            } else if (opcao.equalsIgnoreCase("e")) {
                if (confirm2 == 1){
                    for ( Pessoa pe : listaPessoas ){ 
                        if ( pe instanceof Professor ) 
                        { 
                            pe.imprimir();
                        }
                    }
                } else {
                    System.out.println("\nNão existe um professor cadastrado!");
                }
            } else if (opcao.equalsIgnoreCase("f")) {
                if (confirm3 == 1){
                    for ( Pessoa pe : listaPessoas ){ 
                        if ( pe instanceof TecnicoAdm ) 
                        { 
                            pe.imprimir();
                        }
                    }
                } else {
                    System.out.println("\nNão existe um tecnico cadastrado!");
                }
            } else if (opcao.equalsIgnoreCase("3")) {
                if (confirm1 == 1 || confirm2 == 1 || confirm3 == 1){
                    for(Pessoa pe : listaPessoas){
                        pe.imprimir();
                    }
                } else {
                    System.out.println("\nNão existem pessoas cadastradas!");
                }
            } else if (opcao.equalsIgnoreCase("x")) {
                execute = false;
            } else {
                System.out.println("\nOpção Inválida!!");
            }
        }
    }
}