
import java.util.Scanner;

/**
 *
 * @author Thiiago
 */

public class Professor extends Pessoa {
    
    private String area;
    private String tipoContrato;
    
    public Professor(){}
    
    public Professor(String prontuario, String nome, String area, String tipoContrato)
    {
        super(prontuario, nome);
        this.area = area;
        this.tipoContrato = tipoContrato;
    }
    
    @Override
    public void ler()
    {
        super.ler();
        
        Scanner ler = new Scanner(System.in);
        
        System.out.print("Area.........: ");
        this.area = ler.nextLine();        
        System.out.print("Contrato.....: ");
        this.tipoContrato = ler.nextLine();                  
        
    }
       
    @Override
    public void imprimir()
    {
        super.imprimir();
        
        System.out.println("Area.........: " +  this.area);
        System.out.println("Contrato.....: " +  this.tipoContrato);      
    }        
}
