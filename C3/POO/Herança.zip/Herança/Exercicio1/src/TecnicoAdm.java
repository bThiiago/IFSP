
import java.util.Scanner;

/**
 *
 * @author Thiiago
 */

public class TecnicoAdm extends Pessoa {
    
    private String setor;
    private String cargo;
    
    public TecnicoAdm(){}
    
    public TecnicoAdm(String prontuario, String nome, String setor, String cargo)
    {
        super(prontuario, nome);
        this.setor = setor;
        this.cargo = cargo;
    }
    
    @Override
    public void ler()
    {
        super.ler();
        
        Scanner ler = new Scanner(System.in);
        
        System.out.print("Setor........: ");
        this.setor = ler.nextLine();        
        System.out.print("Cargo........: ");
        this.cargo = ler.nextLine();                  
        
    }
       
    @Override
    public void imprimir()
    {
        super.imprimir();
        
        System.out.println("Setor........: " +  this.setor);
        System.out.println("Cargo........: " +  this.cargo);      
    }        
}
