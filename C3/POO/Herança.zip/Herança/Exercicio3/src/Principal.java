
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author Thiiago
 */

public class Principal {
    
    public static void main(String[] args) {
    
    ArrayList<FuncionarioBase> funcionarios = new ArrayList<>();
    
    Scanner l = new Scanner(System.in);
    String opcao;
    double totalIR = 0;
    double totalINSS = 0;
    double totalSL = 0;
    
    boolean execute = true;
                
        while (execute) {
            System.out.println("\n(!) Cadastrar funcionários (!)");
            System.out.println(" A - Cadastrar funcionário comum");
            System.out.println(" B - Cadastrar funcionário comissado");
            System.out.println(" C - Cadastrar funcionário diarista");
            System.out.println("\n 1 - Listar funcionarios");
            System.out.println(" 2 - Apresentar o total do INSS, IR e Salário Liquido.");
            System.out.println(" X - Sair");
            System.out.print("\nSelecione a opção: ");
            opcao = l.nextLine();

            if (opcao.equalsIgnoreCase("a")) {
                FuncionarioComum fc = new FuncionarioComum();
                funcionarios.add(fc);
                fc.ler();
            } else if (opcao.equalsIgnoreCase("b")) {
                FuncionarioComissionado fcm = new FuncionarioComissionado();
                funcionarios.add(fcm);
                fcm.ler();
            } else if (opcao.equalsIgnoreCase("c")) {
                FuncionarioDiarista fd = new FuncionarioDiarista();
                funcionarios.add(fd);
                fd.ler();
            } else if (opcao.equalsIgnoreCase("1")) {
                for ( FuncionarioBase fb : funcionarios ){ 
                    if ( fb instanceof FuncionarioComum ) 
                    { 
                        fb.imprimir();
                    }
                    if ( fb instanceof FuncionarioComissionado ) 
                    { 
                        fb.imprimir();
                    } 
                    if ( fb instanceof FuncionarioDiarista ) 
                    { 
                        fb.imprimir();
                    } 
                }
            } else if (opcao.equalsIgnoreCase("2")) {
                for ( FuncionarioBase fb : funcionarios ){ 
                    if ( fb instanceof FuncionarioComum ) 
                    { 
                        totalIR = totalIR + fb.getIR();
                        totalINSS = totalINSS + fb.getINSS();
                        totalSL = totalSL + fb.getSalarioLiquido();
                    }
                    if ( fb instanceof FuncionarioComissionado ) 
                    { 
                        totalIR = totalIR + fb.getIR();
                        totalINSS = totalINSS + fb.getINSS();
                        totalSL = totalSL + fb.getSalarioLiquido();
                    } 
                    if ( fb instanceof FuncionarioDiarista ) 
                    { 
                        totalIR = totalIR + fb.getIR();
                        totalINSS = totalINSS + fb.getINSS();
                        totalSL = totalSL + fb.getSalarioLiquido();
                    } 
                }
                System.out.println("\nTotal do INSS: " + totalINSS);
                System.out.println("Total do IR: " + totalIR);
                System.out.println("Total do Salario Liquido: " + totalSL);
            } else if (opcao.equalsIgnoreCase("x")) {
                execute = false;
            } else {
                System.out.println("\nOpção Inválida!! \n");
            }
        }
    }
}