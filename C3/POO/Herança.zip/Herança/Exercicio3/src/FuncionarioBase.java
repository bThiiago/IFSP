
import java.util.Scanner;

/**
 *
 * @author Thiiago
 */

public abstract class FuncionarioBase {
        private String nrRegistro;
	private String nome;
	private String cargo;
        
        public FuncionarioBase(){}
	
	public FuncionarioBase(String registro, String nome, String cargo )
	{
		this.nrRegistro = registro;
		this.nome = nome;
		this.cargo = cargo;
	}
	
	public void ler()
        {
            Scanner ler = new Scanner(System.in);
            
            System.out.print ("\nRegistro...: ");
            this.nrRegistro = ler.nextLine();
            System.out.print ("Nome.......: ");
            this.nome = ler.nextLine();
            System.out.print ("Cargo......: ");
            this.cargo = ler.nextLine();
        }

        public void imprimir()
        {
            System.out.println("\nNome...............: " +  this.nome);
        }

	public abstract double getSalarioBruto();
	public abstract double getINSS();
	public abstract double getIR();
	public abstract double getSalarioLiquido();
	
}
