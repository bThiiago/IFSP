
import java.util.Scanner;

/**
 *
 * @author Thiiago
 */

public class FuncionarioComissionado extends FuncionarioBase {
        private double valorVendas;
	private double taxaComissao;
	private double salarioBase;
        
        public FuncionarioComissionado(){}
	
	public FuncionarioComissionado(String nrRegistro, String nome, String cargo, double valorV, double taxaC, double salarioB )
	{
		super(nrRegistro, nome, cargo );
		this.valorVendas = valorV;
                this.taxaComissao = taxaC;
                this.salarioBase = salarioB;
	}
	
	@Override
        public void ler()
        {
            Scanner ler = new Scanner(System.in);
            super.ler();
            
            System.out.print("Vendas.....: "); 
            this.valorVendas = ler.nextDouble();
            System.out.print("Salario....: "); 
            this.salarioBase = ler.nextDouble();
            System.out.print("Comissao...: "); 
            this.taxaComissao = ler.nextDouble();
        }
        
        @Override
        public void imprimir()
        {
            super.imprimir();
            System.out.println("INSS...............: " +  getINSS());
            System.out.println("Imposto de Renda...: " +  getIR());
            System.out.println("Salario Bruto......: " +  getSalarioBruto());
            System.out.println("Salario Liquido....: " +  getSalarioLiquido()); 
        }
	
	
	@Override
	public double getSalarioBruto()
	{
		return this.salarioBase + this.taxaComissao * this.valorVendas;
	}
        
        @Override
        public double getINSS()
        {
            double salario = getSalarioBruto();
            
            if(salario <= 2000)
            {
                salario = (getSalarioBruto() * 1.08) - getSalarioBruto();
            } 
            else if ( salario > 2000)
            {
                salario = (getSalarioBruto() * 1.11) - getSalarioBruto();
            }
            
        return salario;
        }
        
        @Override
        public double getIR()
        {
            double salario = getSalarioBruto();
            
            if(salario < 2000)
            {
                salario = 0;
            } 
            else if ( salario >= 2000 && salario <= 4000)
            {
                salario = (getSalarioBruto() * 1.15) - getSalarioBruto();
            }
            else if ( salario > 4000)
            {
                salario = (getSalarioBruto() * 1.25) - getSalarioBruto();
            }
            
        return salario;
        }
        
        @Override
        public double getSalarioLiquido()
        {
            double liquido = getSalarioBruto() - getINSS() - getIR();
            return liquido;
        }
}
