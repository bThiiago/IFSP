
import java.util.Scanner;

/**
 *
 * @author Thiiago
 */

public class FuncionarioDiarista extends FuncionarioBase {
        private double valorDiaria;
        private double diasTrabalhados;
        
        public FuncionarioDiarista(){}
	
	public FuncionarioDiarista(String nrRegistro, String nome, String cargo, double valorD, double diasT )
	{
		super(nrRegistro, nome, cargo );
		this.valorDiaria = valorD;
                this.diasTrabalhados = diasT;
	}
	
	@Override
        public void ler()
        {
            Scanner ler = new Scanner(System.in);
            super.ler();
            
            System.out.print("Diaria.....: "); 
            this.valorDiaria = ler.nextDouble();
            System.out.print("Dias.......: "); 
            this.diasTrabalhados = ler.nextDouble();
        }
        
        @Override
        public void imprimir()
        {
            super.imprimir();
            System.out.println("INSS...............: " +  getINSS());
            System.out.println("Imposto de Renda...: " +  getIR());
            System.out.println("Salario Bruto......: " +  getSalarioBruto());
            System.out.println("Salario Liquido....: " +  getSalarioLiquido()); 
        }
        
	@Override
	public double getSalarioBruto()
	{
            return this.valorDiaria * this.diasTrabalhados;
	}
        
        @Override
        public double getINSS()
        {
            double salario = getSalarioBruto();
            
            if(salario <= 2000)
            {
                salario = (getSalarioBruto() * 1.08) - getSalarioBruto();
            } 
            else if ( salario > 2000)
            {
                salario = (getSalarioBruto() * 1.11) - getSalarioBruto();
            }
            
        return salario;
        }
        
        @Override
        public double getIR()
        {
            double salario = getSalarioBruto();
            
            if(salario < 2000)
            {
                salario = 0;
            } 
            else if ( salario >= 2000 && salario <= 4000)
            {
                salario = (getSalarioBruto() * 1.15) - getSalarioBruto();
            }
            else if ( salario > 4000)
            {
                salario = (getSalarioBruto() * 1.25) - getSalarioBruto();
            }
            
        return salario;
        }
        
        @Override
        public double getSalarioLiquido()
        {
            double liquido = getSalarioBruto() - getINSS() - getIR();
            return liquido;
        }
}
