
import java.util.Scanner;

/**
 *
 * @author Thiiago
 */

public class Principal {
    
    public static void main(String[] args) {
        
        GerenciaDisciplinas gd = new GerenciaDisciplinas();
        Scanner ler = new Scanner(System.in);
        
        int op;
        
        do{
            System.out.println("\nMenu principal\n");
            
            System.out.println("1 - Ler 7 disciplinas");
            System.out.println("2 - Digitar as notas e frequências dessas disciplinas");
            System.out.println("3 - Alterar os dados de uma determinada disciplina");
            System.out.println("4 - Apresentar a situação de todas as disciplinas");
            System.out.println("5 - Apresentar as disciplinas onde o aluno foi aprovado");
            System.out.println("6 - Apresentar a média global do aluno");
            System.out.println("7 - Apresentar as disciplinas onde o aluno teve nota máxima");
            System.out.println("0 - Sair");

            System.out.print("Digite a opção desejada..: ");
            op = ler.nextInt();
            
            switch(op)
            {
                case 1: gd.cadastrarDisciplinas();
                        break;
                case 2: gd.cadastrarNota();
                        break;
                case 3: gd.alterarDados();
                        break;
                case 4: gd.situacaoDisciplinas();
                        break;
                case 5: gd.aprovado();
                        break;
                case 6: gd.mediaGlobal();
                        break;
                case 7: gd.notaMaxima();
                        break;
                case 8: gd.listarDisciplinas();
                        break;
            }         
        } while (op != 0);
    }
}
