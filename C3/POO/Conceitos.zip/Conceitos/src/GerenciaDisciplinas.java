
import java.util.Scanner;

/**
 *
 * @author Thiiago
 */

public class GerenciaDisciplinas {
    
    private Disciplina[] disciplinas = new Disciplina[2];
    
    public void cadastrarDisciplinas()
    {
        for(int i=0;i<2;i++)
        {
            disciplinas[i] = new Disciplina();            
            disciplinas[i].lerDados();
        }
    }
    
    public void cadastrarNota()
    {
        for(int i=0;i<2;i++)
        {
            disciplinas[i].digitarNotas();
            disciplinas[i].entrarFrequecia();
        }
    }
    
    public void alterarDados()
    {
        Scanner ler = new Scanner(System.in);
        
        String sigla;
        
        System.out.print("Digite a sigla da disciplina: ");
        sigla = ler.nextLine();
        
        for(int i=0;i<2;i++)
        {
            if (this.disciplinas[i].getSigla().equals(sigla))
            {
               this.disciplinas[i].apresentarDados(); 
            }
        }        
    }
    
    public void situacaoDisciplinas()
    {
        System.out.println("\n   -SITUAÇÃO-");
        for(int i=0;i<2;i++)
        {
            this.disciplinas[i].apresentarSituacao();
            System.out.println("");
        }
    }
    
    public void aprovado()
    {
        System.out.println("\n   -APROVADO-");
        for(int i=0;i<2;i++)
        {
            if (this.disciplinas[i].aprovados() == 1)
            {
            this.disciplinas[i].apresentarSituacao();
            }
        }   
    }
    
    public void mediaGlobal()
    {
        float media=0;
        
        System.out.println("\n   -SITUAÇÃO-");
        
        for(int i=0;i<2;i++)
        {
            media = media + disciplinas[i].retornaMedia();
        }
        media = media/2;
        
        System.out.println("\nMedia global do aluno: " + media);
    }
    
    public void notaMaxima()
    {
        System.out.println("\n   -NOTA MÁXIMA-");
        for(int i=0;i<2;i++)
        {
            if (this.disciplinas[i].nota() == 1)
            {
            this.disciplinas[i].apresentarSituacao();
            }
        }   
    }
    
    public void listarDisciplinas()
    {
        for(int i=0;i<2;i++)
        {
            this.disciplinas[i].apresentarDados();
        }
    }
    
}
