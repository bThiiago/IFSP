
import java.util.Scanner;

/**
 *
 * @author Thiiago
 */

public class Disciplina {
    
    private String sigla;
    private String nome; 
    private String professor;
    private float nota1 ;
    private float nota2;
    private float frequencia;
    
    public void lerDados()
    {
        Scanner ler = new Scanner(System.in);
        
        System.out.print("\nSigla........: ");
        this.sigla = ler.nextLine();

        System.out.print("Nome.........: ");
        this.nome = ler.nextLine();        
        
        System.out.print("Professor....: ");
        this.professor = ler.nextLine();
    }
    
    public void digitarNotas()
    {
        Scanner ler = new Scanner(System.in);
        
        System.out.print("\nNota1........: ");
        this.nota1 = ler.nextFloat();        

        System.out.print("Nota2........: ");
        this.nota2 = ler.nextFloat(); 
    }
    
    public void entrarFrequecia()
    {
        Scanner ler = new Scanner(System.in);
        
        System.out.print("\nFrequencia...: ");
        this.frequencia = ler.nextFloat(); 
    }
    
    public void apresentarDados()
    {
        System.out.println("\nSigla........: " + this.sigla);

        System.out.println("Nome.........: " + this.nome);
        
        System.out.println("Professor....: " + this.professor);
        
        System.out.println("Nota1........: " + this.nota1);

        System.out.println("Nota2........: " + this.nota2);
        
        System.out.println("Frequencia...: " + this.frequencia);
    }
    
    public void apresentarSituacao()
    {
        float media;
        
        media = (this.nota1+this.nota2)/2;
        
        System.out.println("\nDisciplina...: " + this.nome);
        System.out.println("Media........: " + media);
        System.out.println("Frequencia...: " + this.frequencia);
            
        if(media >= 6 && this.frequencia >= 75){
            
            System.out.println("Situacao.....: Aprovado");
            
        }else if(media >= 6 && this.frequencia < 75){
            
            System.out.println("Situacao.....: Retido por falta");
            
        }else if(media < 6 && this.frequencia >= 75){
            
            System.out.println("Situacao.....: Retido por nota");
            
        }else if(media < 6 && this.frequencia < 75){
            
            System.out.println("Situacao.....: Retido por falta e nota");
            
        }

    }
    
    public int aprovados()
    {
        float media;
        int confirm = 0;
        
        media = (this.nota1+this.nota2)/2;
        
        if(media >= 6 && this.frequencia >= 75)
            confirm =1;
            
        return confirm;
    }
    
    public int nota()
    {
        int confirm = 0;
        
        if(this.nota1 == 10 && this.nota2 == 10)
            confirm =1;
            
        return confirm;
    }
    
    public String getSigla()
    {
        return this.sigla;
    }
    
    public float retornaMedia()
    {
        float media;
        
        media = (this.nota1+this.nota2)/2;
        
        return media;
    }
}