
package Screen;

import Controllers.DespesaController;
import Controllers.MovimentoController;
import Controllers.SalarioController;
import Controllers.VendaController;
import java.util.Scanner;

/**
 *
 * @author Thiiago
 */

public class Principal {
    
    public static void main(String[] args) {
        
    Scanner read = new Scanner(System.in);
    
    DespesaController dc = new DespesaController();
    SalarioController sc = new SalarioController();
    VendaController vc = new VendaController();
    MovimentoController mc = new MovimentoController(dc, sc, vc);

    int op;

        do {
            System.out.println("\n1 - Incluir despesa");
            System.out.println("2 - Listar despesas");
            System.out.println("3 - Incluir venda");
            System.out.println("4 - Listar vendas");
            System.out.println("5 - Incluir pagamento");
            System.out.println("6 - Listar pagamentos");
            System.out.println("7 - Apresentar extrato de movimentação financeira");
            System.out.println("0 - Sair do programa");
            System.out.print("\nInforme a opcao...: ");
            op = read.nextInt();
            System.out.println("");
            
            switch (op) {
                case 1:
                    dc.readDespesa();
                    break;
                case 2:
                    dc.showDespesa();
                    break;
                case 3:
                    vc.readVenda();
                    break;
                case 4:
                    vc.showVenda();
                    break;
                case 5:
                    sc.readSalario();
                    break;
                case 6:
                    sc.showSalario();
                    break;
                case 7:
                    mc.addMovimento();
                    break;
            }
        } while (op != 0);
    }
}
