
package Controllers;

import Models.Movimento;
import java.util.ArrayList;

/**
 *
 * @author Thiiago
 */

public class MovimentoController {
    ArrayList<Movimento> movimentos = new ArrayList<>();

    private DespesaController despesas;
    private SalarioController salarios;
    private VendaController vendas;

    public MovimentoController(DespesaController despesas, SalarioController salarios, VendaController vendas) {
        this.despesas = despesas;
        this.salarios = salarios;
        this.vendas = vendas;
    }

    public void addMovimento() {

        this.movimentos.addAll(this.despesas.despesas);
        this.movimentos.addAll(this.salarios.salarios);
        this.movimentos.addAll(this.vendas.vendas);

        for (Movimento m : movimentos) {

            System.out.println(m.getMovimento());

        }
        System.out.println("\nSaldo final: " + total());
    }

    public double total() {

        double total = 0;

        total = this.salarios.somaSalario() + this.despesas.somaSalario() + this.vendas.somaSalario();

        return total;

    }
}
