
package Controllers;

import Models.Venda;
import java.util.ArrayList;

/**
 *
 * @author Thiiago
 */

public class VendaController {
    ArrayList<Venda> vendas = new ArrayList<>();
    
    public VendaController(){}

    public void readVenda() {
        Venda v = new Venda();
        v.readVenda();
        this.vendas.add(v);
    }

    public void showVenda() {
        for (Venda d : vendas) {
            d.showVenda();
        }
    }
    
    public ArrayList<Venda> getDespesas() {
        return this.vendas;
    }
    
    public double somaSalario() {
        double s = 0;

        for (Venda v : vendas) {
            s += v.getValorMovimento();
        }

        return s;
    }
}
