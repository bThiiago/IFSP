
package Controllers;

import Models.Despesa;
import java.util.ArrayList;

/**
 *
 * @author Thiiago
 */

public class DespesaController {
    ArrayList<Despesa> despesas = new ArrayList<>();
    
    public DespesaController(){}

    public void readDespesa() {
        Despesa d = new Despesa();
        d.readDespesa();
        this.despesas.add(d);
    }

    public void showDespesa() {
        for (Despesa d : despesas) {
            d.showDespesa();
        }
    }
    
    public ArrayList<Despesa> getDespesas() {
        return this.despesas;
    }
    
    public double somaSalario() {
        double s = 0;

        for (Despesa d : despesas) {
            s += d.getValorMovimento();
        }

        return s;
    }
}
