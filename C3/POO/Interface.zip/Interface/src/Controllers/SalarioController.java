
package Controllers;

import Models.Salario;
import java.util.ArrayList;

/**
 *
 * @author Thiiago
 */

public class SalarioController {
    ArrayList<Salario> salarios = new ArrayList<>();
    
    public SalarioController(){}

    public void readSalario() {
        Salario s = new Salario();
        s.readSalario();
        this.salarios.add(s);
    }

    public void showSalario() {
        for (Salario d : salarios) {
            d.showSalario();
        }
    }
    
    public ArrayList<Salario> getSalarios() {
        return this.salarios;
    }
    
    public double somaSalario() {
        double so = 0;

        for (Salario s : salarios) {
            so += s.getValorMovimento();
        }

        return so;
    }
}
