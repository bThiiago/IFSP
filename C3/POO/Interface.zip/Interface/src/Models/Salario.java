
package Models;

import java.util.Scanner;

/**
 *
 * @author Thiiago
 */

public class Salario implements Movimento {
    private int pront;
    private String nome;
    private String mesAno;
    private String data;
    private double salario;
    
    public Salario(){}
    
    public Salario(int pront, String nome, String mesAno, String data, double salario){
        this.pront = pront;
        this.nome = nome;
        this.mesAno = mesAno;
        this.data = data;
        this.salario = salario;
    }
    
    public void readSalario() {
        Scanner read = new Scanner(System.in);

        System.out.print("Digite o prontuario do salario...: ");
        this.pront = read.nextInt(); read.nextLine();

        System.out.print("Digite o nome do salario.........: ");
        this.nome = read.nextLine();
        
        System.out.print("Digite o mes ano do salario......: ");
        this.mesAno = read.nextLine();

        System.out.print("Digite a data do salario.........: ");
        this.data = read.nextLine();
        
        System.out.print("Digite o valor do salario........: ");
        this.salario = read.nextDouble(); read.nextLine();
    }
    
    public void showSalario() {
        System.out.println("Prontuario do salario...: " + this.pront);
        System.out.println("Nome do salario.........: " + this.nome);
        System.out.println("Mes ano do salario......: " + this.mesAno);
        System.out.println("Data do salario.........: " + this.data);
        System.out.println("Valor do salario........: " + this.salario);
    }
    
    public int getPront(){
        return pront;
    }
    
    public void setPront(int pront){
        this.pront = pront;
    }
    
    public String getNome(){
        return nome;
    }
    
    public void setNome(String nome){
        this.nome = nome;
    }
    
    public String getMes(){
        return mesAno;
    }
    
    public void setMes(String mesAno){
        this.mesAno = mesAno;
    }
    
    public String getData(){
        return data;
    }
    
    public void setData(String data){
        this.data = data;
    }
    
    public double getSalario(){
        return salario;
    }
    
    public void setSalario(double salario){
        this.salario = salario;
    }
    
    @Override
    public String getMovimento(){
        return "Salario...: " + this.data + " - " + this.nome + " - " + this.mesAno + " - R$" + this.salario;
    }
    
    @Override
    public double getValorMovimento(){
        return this.salario;
    }
}
