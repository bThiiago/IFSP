
package Models;

import java.util.Scanner;

/**
 *
 * @author Thiiago
 */

public class Venda implements Movimento {
    private int nrNota;
    private String data;
    private String formaPgto;
    private double valor;
    
    public Venda(){}
    
    public Venda(int nrNota, String data, String formaPgto, double valor){
        this.nrNota = nrNota;
        this.data = data;
        this.formaPgto = formaPgto;
        this.valor = valor;
    }
    
    public void readVenda() {
        Scanner read = new Scanner(System.in);

        System.out.print("Digite o numero da nota.......: ");
        this.nrNota = read.nextInt(); read.nextLine();

        System.out.print("Digite a data da venda........: ");
        this.data = read.nextLine();
        
        System.out.print("Digite a forma de pagamento...: ");
        this.formaPgto = read.nextLine();
        
        System.out.print("Digite o valor da venda.......: ");
        this.valor = read.nextDouble(); read.nextLine();
    }
    
    public void showVenda() {
        System.out.println("Numero da nota.......: " + this.nrNota);
        System.out.println("Data da venda........: " + this.data);
        System.out.println("Forma de pagamento...: " + this.formaPgto);
        System.out.println("Valor da venda.......: " + this.valor);
    }
    
    public int getNota(){
        return nrNota;
    }
    
    public void setNota(int nrNota){
        this.nrNota = nrNota;
    }
    
    public String getData(){
        return data;
    }
    
    public void setData(String data){
        this.data = data;
    }
    
    public String getForma(){
        return formaPgto;
    }
    
    public void setForma(String formaPgto){
        this.formaPgto = formaPgto;
    }
    
    public double getValor(){
        return valor;
    }
    
    public void setValor(double valor){
        this.valor = valor;
    }
    
    @Override
    public String getMovimento(){
        return "Venda.....: " + this.data + " - " + this.nrNota + " - " + this.formaPgto + " - R$" + this.valor;
    }
    
    @Override
    public double getValorMovimento(){
        return this.valor;
    }
}
