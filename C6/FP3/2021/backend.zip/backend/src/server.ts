import express from 'express';

const PORT = process.env.PORT || 3333;

const app = express();

const nomes = ['cesar', 'ana'];

app.get("/", (req, res) => {
    res.send("Resposta do Backend");
})

app.get("/users", (req, res) => {
    console.log(req.query.search);
    res.send(`Parâmetro da requisição ${req.query['search']}`);
})

app.get("/users/:id/:valor", (req, res) => {
    console.log(req.params.id);
    res.send(`Parâmetro da requisição ${req.params.id}`);
})

//Criar rotas
//Somar dois números e retornar o resultado

//Pesquisar nomes
//Cria um vetor (backend) e uma rota que receba um nome para pesquisa e devolva o resultado da pesquisa
//filter e includes




app.listen(PORT as number,  () => console.log(`Listening on all interfaces:${PORT}`));
