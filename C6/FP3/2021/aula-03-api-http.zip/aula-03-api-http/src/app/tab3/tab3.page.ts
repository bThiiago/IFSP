import { Component } from '@angular/core';
import { PostsService } from '../api/posts.service';

@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss']
})
export class Tab3Page {

  constructor(private api: PostsService) {
    console.log("construtor do tab3");

    api.getPosts()
    //SUCESSO
    .then( (posts) => {
      console.log(posts);
    })
    //ERRO
    .catch( (erro) => {
      console.log(erro);
    });
  }

}
