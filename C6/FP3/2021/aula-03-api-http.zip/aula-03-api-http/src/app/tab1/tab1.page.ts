import { Component } from '@angular/core';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page {
  private contador = 0;
  nome = "Maria";
  titulo = "Ferramentas de Programação III";

  constructor() {}

  exibir() {
    console.log("botão pressionado");

    this.contador++;
    this.titulo = "Ferramentas de Programação " + this.contador;


    console.log(this.nome);

    this.nome = "Carla";
  }

}
