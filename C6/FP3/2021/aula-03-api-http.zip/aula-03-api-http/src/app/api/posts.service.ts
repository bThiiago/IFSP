import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class PostsService {

  constructor(private http: HttpClient) {
    console.log("Construtor do serviço posts");
  }

  public getPosts() {
    // REQUISIÇÕES ASSÍNCRONAS

    //VERBO ENDEREÇO (URL) RECURSO PARÂMETROS
    return this.http.get('https://jsonplaceholder.typicode.com/posts').toPromise();

  }
}
