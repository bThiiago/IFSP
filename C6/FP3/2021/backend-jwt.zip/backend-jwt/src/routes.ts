import { Router } from "express";
import authentication from "../ src/middleware/authentication";
import UsersController from "./controllers/UsersController";

const routes = Router();

routes.post("/login", UsersController.login);
routes.get("/users", authentication.validate, UsersController.index);

export default routes;