import { Request, Response } from "express";
// import * as jwt from "jsonwebtoken";
const jwt = require("jsonwebtoken");

export default {
  async index(request: Request, response: Response) {
    const usuarios = [
      {
        email: "user1@email.com",
        senha: "123",
      },
      {
        email: "user2@email.com",
        senha: "123",
      },
    ];

    response.status(200).json(usuarios);
  },
  async login(request: Request, response: Response) {
    //desestruturacao
    const { email, senha } = request.body;

    //Verificação somente para testes (substituir)
    if (email === senha) {
      const payload = {
        email,
      };

      const token = jwt.sign(payload, process.env.ACCESS_TOKEN_SECRET, {
        expiresIn: 300, // expires in 5min
      });

      return response.status(200).json({
        token: token,
      });
    }
    return response.status(500).json({ message: "Login inválido!" });
  },
};