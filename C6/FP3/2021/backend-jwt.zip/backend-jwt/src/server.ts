import express from 'express';
import * as dotenv from "dotenv";
var cors = require("cors");

import routes from './routes';

const PORT = process.env.PORT || 3333;

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

app.use(routes);

app.listen(PORT as number,  () => console.log(`Listening on all interfaces:${PORT}`));