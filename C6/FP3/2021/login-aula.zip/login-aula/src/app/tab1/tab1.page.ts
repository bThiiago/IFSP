import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ToastController } from '@ionic/angular';
import { UsuarioService } from '../api/usuario.service';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page {

  user: string;
  password: string;

  constructor(private usuarioService: UsuarioService, private router: Router,
    private toastController: ToastController) { }

  async login() {
    const usuario = {
      email: this.user,
      senha: this.password
    }
    await this.usuarioService.login(usuario);
    if (this.usuarioService.isLogin()) {
      this.router.navigate(['/tabs/tab2']);
    } else {
      this.presentToast("User or password is invalid.");
    }
  }

  logout() {
    this.usuarioService.logout();
  }

  async presentToast(message: string) {
    const toast = await this.toastController.create({
      message: message,
      duration: 2000
    });
    toast.present();
  }
}
