import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UsuarioService {

  private urlBase = 'http://localhost:3333'

  private token: string = null;

  constructor(private http: HttpClient) { }

  private getHttpOptions() {
    const httpOptions = {
      headers: new HttpHeaders({
        Authorization: 'Bearer ' + this.token,
      }),
    };
    return httpOptions;
  }

  findAll() {
    return this.http.get(`${this.urlBase}/users`, this.getHttpOptions()).toPromise();
  }

  async login(user) {
    await this.http.post(`${this.urlBase}/login`, user)
    .toPromise()
    .then((resultado: any)=> {      
      this.token = resultado.token;
    })
    .catch( error => {
      console.error(error.error.message);
    });
  }

  logout() {
    this.token = null;
  }

  isLogin() {
    return this.token ? true : false;
  }
}
