import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { UsuarioService } from '../api/usuario.service';

@Injectable({
  providedIn: 'root'
})
export class AcessoService implements CanActivate {

  constructor(private router: Router, private usuarioService: UsuarioService) { }

  canActivate(): boolean {

    console.log("chegou no serviço de acesso.");

    if (!this.usuarioService.isLogin()) {
      this.router.navigate(['/tabs/tab1']); //módulo de login
      return false;
    }
    return true;
  }
}
