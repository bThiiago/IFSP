import { Router } from "express";
import UsersController from "./controllers/UsersController";

const routes = Router();

routes.post("/users", UsersController.create );
routes.get("/users", UsersController.index);
routes.get("/users/find", UsersController.findByName);
routes.get("/users/find/:id", UsersController.show);



const nomes = ['cesar', 'ana'];

routes.get("/", (req, res) => {
    res.send("Resposta do Backend");
})


routes.get("/users/:id/:valor", (req, res) => {
    console.log(req.params.id);

    const { id } = req.params;

    res.send(`Parâmetro da requisição ${req.params.id}`);
})

//Criar rotas
//Somar dois números e retornar o resultado

//Pesquisar nomes
//Cria um vetor (backend) e uma rota que receba um nome para pesquisa e devolva o resultado da pesquisa
//filter e includes


export default routes;