/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifsp.pep.relatorio;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.persistence.EntityManager;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.query.JRJpaQueryExecuterFactory;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

/**
 *
 * @author Aluno
 */
public class GerarRelatorio {

    public void gerar(EntityManager em, String relatorio) {

        try {
            //carrega o arquivo com o layout do relatorio
            JasperDesign jd = JRXmlLoader
              .load(getClass()
              .getResourceAsStream(
              "/br/edu/ifsp/pep/relatorio/" + relatorio));

            //compila o relatorio
            JasperReport relatorioCompilado
                    = JasperCompileManager
                            .compileReport(jd);
            //parametros
            HashMap<String, Object> parametros = new HashMap<>();
            parametros.put(
                     JRJpaQueryExecuterFactory
                     .PARAMETER_JPA_ENTITY_MANAGER,
                    em);
            parametros.put("state", "FL");

            BufferedImage bi = null;
            try {
                bi = ImageIO.read(getClass()
                        .getResource(
                                "/br/edu/ifsp/pep/relatorio/logo.png"));
            } catch (IOException ex) {
                System.out.println("Erro ao carregar imagem.");
            }

            parametros.put("logo", bi);

            //preenche o relatorio com os dados da tabela do banco
            JasperPrint jp = JasperFillManager
                    .fillReport(relatorioCompilado, parametros);

            //exibe o relatorio
            JasperViewer viewer
                    = new JasperViewer(jp, false);
            viewer.setVisible(true);
        } catch (JRException ex) {
            Logger.getLogger(GerarRelatorio.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    
     public void gerarJasper(EntityManager em, String relatorio) {

        try {
            //parametros
            HashMap<String, Object> parametros = new HashMap<>();
            parametros.put(
                     JRJpaQueryExecuterFactory
                     .PARAMETER_JPA_ENTITY_MANAGER,
                    em);
            parametros.put("state", "FL");

            InputStream jasper = getClass().getResourceAsStream(
                    "/br/edu/ifsp/pep/relatorio/" + relatorio);

            //preenche o relatorio com os dados da tabela do banco
            JasperPrint jp = JasperFillManager
                    .fillReport(jasper, parametros);

            //exibe o relatorio
            JasperViewer viewer
                    = new JasperViewer(jp, true);
            viewer.setVisible(true);
        } catch (JRException ex) {
            Logger.getLogger(GerarRelatorio.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
}
