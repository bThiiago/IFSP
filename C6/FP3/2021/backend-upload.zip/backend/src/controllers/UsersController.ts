import { Request, Response } from "express";
import { getRepository } from "typeorm";
import User from "../models/User";


export default {
    async create(req: Request, res: Response) {
        console.log(req.body);

        //desestruturar o corpo da requisição (JSON)
        const { name, salary } = req.body;
        // const { nome, salario } = req.body;

        const userRepository = getRepository(User);

        // const user = new User();
        // user.nome = nome;
        // user.salario = salario;

        // const user = userRepository.create({
        //   nome: name,
        //   salario: salary,
        // });

        // const user = userRepository.create({
        //   nome,
        //   salario
        // });

        // await userRepository.save(user);
        const u = await userRepository.save({
            nome: name,
            salario: salary
        });

        return res.status(201).json(u);
    },
    async index(req: Request, res: Response) {
        const repository = getRepository(User);
        const users = await repository.find();

        res.json(users);
    },
    async show(req: Request, res: Response) {
        const { id } = req.params;
        const repository = getRepository(User);
        const user = await repository.findOneOrFail(id);

        res.json(user);
    },
    async findByName(req: Request, res: Response) {
        const { nome } = req.query;
        const repository = getRepository(User);
        const users = await repository.findOne({nome: nome as string});
        console.log(users);

        res.json(users);
    }

}