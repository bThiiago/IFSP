
package br.edu.ifsp.pep.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author Thiiago
 */

public class Conexao {
    public static Connection getConexao() throws SQLException {
        return DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/db_produtos?useSSL=false",
                "root",
                "1234");
    }
}