
package br.edu.ifsp.pep.dao;

import br.edu.ifsp.pep.model.Produto;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;
import java.util.ArrayList;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Thiiago
 */

public class ProdutoDAO {

    public ProdutoDAO() {}

    public void inserir(Produto produto) {
        System.out.println("Produto armazenado.");
        
        Connection conexao = null;
        PreparedStatement ps = null;
        try {
            conexao = Conexao.getConexao();
            String sql = "INSERT INTO produto (nome, preco_compra, preco_venda, data_validade, quantidade) VALUES (?, ?, ?, ?, ?)";
            ps = conexao.prepareStatement(sql);
            ps.setString(1, produto.getNome());
            ps.setDouble(2, produto.getPrecoCompra());
            ps.setDouble(3, produto.getPrecoVenda());
            
            Date date = produto.getDataValidade();
            if (date != null) {
                java.sql.Date data = new java.sql.Date(produto.getDataValidade().getTime());
                ps.setDate(4, data);
            } else {
                ps.setDate(4, null);
            }
            
            ps.setInt(5, produto.getQuantidade());
            
            ps.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(ProdutoDAO.class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Erro na conexão com o banco de dados.");
        } finally {
            try {
                ps.close();
                conexao.close();
            } catch (SQLException ex) {
                Logger.getLogger(ProdutoDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    public List<Produto> listar() {
        
        List<Produto> produtos = new ArrayList<>();
        
        Connection conexao = null;
        PreparedStatement ps = null;

        try {
            conexao = Conexao.getConexao();
            
            String sql = "SELECT id, nome, preco_compra, preco_venda, data_validade, quantidade FROM produto";
            
            ps = conexao.prepareStatement(sql);
            
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                Produto produto = new Produto();
                produto.setId(rs.getInt("id"));
                produto.setNome(rs.getString("nome"));
                produto.setPrecoCompra(rs.getDouble("preco_compra"));
                produto.setPrecoVenda(rs.getDouble("preco_venda"));
                
                Date date = rs.getDate("data_validade");
                if (date != null) {
                    produto.setDataValidade(new java.util.Date(date.getTime()));
                }
                
                produto.setQuantidade(rs.getInt("quantidade"));
                
                produtos.add(produto);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(ProdutoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return produtos;
    }
    
    public List<Produto> buscar(String nomeBusca) {
        
        List<Produto> produtos = new ArrayList<>();
        
        Connection conexao = null;
        PreparedStatement ps = null;

        try {
            conexao = Conexao.getConexao();
            
            String sql = "SELECT id, nome, preco_compra, preco_venda, data_validade, quantidade FROM produto WHERE nome LIKE ?";
            
            ps = conexao.prepareStatement(sql);
            
            ps.setString(1, nomeBusca);
            
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                Produto produto = new Produto();
                produto.setId(rs.getInt("id"));
                produto.setNome(rs.getString("nome"));
                produto.setPrecoCompra(rs.getDouble("preco_compra"));
                produto.setPrecoVenda(rs.getDouble("preco_venda"));
                
                Date date = rs.getDate("data_validade");
                if (date != null) {
                    produto.setDataValidade(new java.util.Date(date.getTime()));
                }
                
                produto.setQuantidade(rs.getInt("quantidade"));
                
                produtos.add(produto);
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(ProdutoDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return produtos;
    }
}
