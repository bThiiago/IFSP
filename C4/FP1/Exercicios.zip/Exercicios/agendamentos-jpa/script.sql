CREATE TABLE IF NOT EXISTS agendamento (
  codigo INT NOT NULL AUTO_INCREMENT,
  descricao VARCHAR(200),
  data DATE NOT NULL,
  horario VARCHAR(50) NOT NULL,
  tipo_servico VARCHAR(100) NOT NULL,
  valor_total FLOAT,
  nome_cliente VARCHAR(100),
PRIMARY KEY (codigo));

INSERT INTO `agendamento` (`descricao`, `data`, `horario`, `tipo_servico`, `valor_total`, `nome_cliente`) VALUES 
('Corte e limpeza facil', '2021-09-30', '13 horas', 'Corte de cabelo', '30', 'Thiago'),
('Tintura cor vinho', '2021-10-03', '15 horas', 'Pintura de cabelo', '110', 'Marco'),
(NULL, '2021-10-05', '11 horas', 'Corte de cabelo', '20', 'Joao'),
('Hidratação capilar e limpeza facial', '2021-10-06', '09 horas', 'Hidratação', '40', 'Zephyr');
