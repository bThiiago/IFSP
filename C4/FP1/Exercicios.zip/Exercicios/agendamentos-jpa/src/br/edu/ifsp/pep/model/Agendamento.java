
package br.edu.ifsp.pep.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;

/**
 *
 * @author Thiiago
 */

@Entity
@Table (name = "agendamento")
public class Agendamento implements Serializable {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "codigo")
    private int codigo;
    @Column(name = "descricao", length = 200, nullable = true)
    private String descricao;
    @Column(name = "data", nullable = false)
    @Temporal(javax.persistence.TemporalType.DATE)
    private Date data;
    @Column(name = "horario", length = 50, nullable = false)
    private String horario;
    @Column(name = "tipo_servico", length = 100, nullable = false)
    private String tipo_servico;
    @Column(name = "valor_total", nullable = true)
    private double valor_total;
    @Column(name = "nome_cliente", length = 100, nullable = true)
    private String nome_cliente;
    
    public Agendamento() {
    }
    
    public Agendamento(String descricao, Date data, String horario, String tipo_servico, double valor_total, String nome_cliente) {
        this.descricao = descricao;
        this.data = data;
        this.horario = horario;
        this.tipo_servico = tipo_servico;
        this.valor_total = valor_total;
        this.nome_cliente = nome_cliente;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    public String getTipo_servico() {
        return tipo_servico;
    }

    public void setTipo_servico(String tipo_servico) {
        this.tipo_servico = tipo_servico;
    }

    public double getValor_total() {
        return valor_total;
    }

    public void setValor_total(double valor_total) {
        this.valor_total = valor_total;
    }

    public String getNome_cliente() {
        return nome_cliente;
    }

    public void setNome_cliente(String nome_cliente) {
        this.nome_cliente = nome_cliente;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 79 * hash + this.codigo;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Agendamento other = (Agendamento) obj;
        if (this.codigo != other.codigo) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Agendamento{" + "codigo=" + codigo + ", descricao=" + descricao + ", data=" + data + ", horario=" + horario + ", tipo_servico=" + tipo_servico + ", valor_total=" + valor_total + ", nome_cliente=" + nome_cliente + '}';
    }
}
