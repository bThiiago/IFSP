
package br.edu.ifsp.pep.dao;

import br.edu.ifsp.pep.model.Agendamento;
import java.util.Date;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

/**
 *
 * @author Thiiago
 */

public class AgendamentoDAO {
    private EntityManagerFactory emf;

    public AgendamentoDAO() {
        this.emf = Persistence.createEntityManagerFactory("agendamentos-jpaPU");
    }

    public void inserir(Agendamento agendamento) {
        System.out.println("Agendamento armazenado.");

        EntityManager em = this.emf.createEntityManager();

        em.getTransaction().begin();
        em.persist(agendamento);
        em.getTransaction().commit();
        em.close();
    }

    public List buscarTodos() {
        EntityManager em = this.emf.createEntityManager();

        Query query = em.createQuery("select a from Agendamento a");
        return query.getResultList();
    }

    public Agendamento buscarCodigo(int codigo) {
        EntityManager em = this.emf.createEntityManager();
        Query query = em.createQuery("select a from Agendamento a where a.codigo = :id");
        query.setParameter("id", codigo);

        return (Agendamento) query.getSingleResult();
    }

    public List<Agendamento> buscarData(Date data) {
        EntityManager em = this.emf.createEntityManager();
        TypedQuery<Agendamento> query = em.createQuery("select a from Agendamento a where a.data = :data", Agendamento.class);
        
        query.setParameter("data", data);

        return query.getResultList();
    }
}
