
package br.edu.ifsp.pep.model;

import java.util.Date;

/**
 *
 * @author Thiiago
 */

public class Produto {
    private int codigo;
    private String nome;
    private double precoCompra;
    private double precoVenda;
    private Date dataValidade;
    private int quantidade;

    public Produto(){}
    
    public Produto(int codigo, String nome, double precoCompra, double precoVenda, Date dataValidade, int quantidade) {
        this.codigo = codigo;
        this.nome = nome;
        this.precoCompra = precoCompra;
        this.precoVenda = precoVenda;
        this.dataValidade = dataValidade;
        this.quantidade = quantidade;
    }
    
    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public double getPrecoCompra() {
        return precoCompra;
    }

    public void setPrecoCompra(double precoCompra) {
        this.precoCompra = precoCompra;
    }

    public double getPrecoVenda() {
        return precoVenda;
    }

    public void setPrecoVenda(double precoVenda) {
        this.precoVenda = precoVenda;
    }

    public Date getDataValidade() {
        return dataValidade;
    }

    public void setDataValidade(Date dataValidade) {
        this.dataValidade = dataValidade;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    @Override
    public String toString() {
        return "Produto{" + "codigo=" + codigo + ", nome=" + nome + ", precoCompra=" + precoCompra + ", precoVenda=" + precoVenda + ", dataValidade=" + dataValidade + ", quantidade=" + quantidade + '}';
    }
}