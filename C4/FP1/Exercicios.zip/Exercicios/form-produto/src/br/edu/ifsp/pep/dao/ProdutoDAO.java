
package br.edu.ifsp.pep.dao;

import br.edu.ifsp.pep.model.Produto;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Thiiago
 */

public class ProdutoDAO {
    private static List<Produto> produtos;

    public ProdutoDAO() {
        if (produtos == null) {
            produtos = new ArrayList<>();
        }
    }

    public void inserir(Produto produto) {
        produtos.add(produto);
        System.out.println("Produto armazenado.");
    }
    
    public List<Produto> buscarTodos() {
        return produtos;
    }
}
