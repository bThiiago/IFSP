
import br.edu.ifsp.pep.modelo.Cliente;
import java.util.Date;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author cesar
 */
public class Teste {
    public static void main(String[] args) {
        
        Cliente cliente = new Cliente();
//        cliente.setId(1);
        cliente.setCpf("222222222222");
        cliente.setEndereco("Rua qualquer 22222");
        cliente.setNome("Nome da pessoa 22222");
        cliente.setDataNascimento(new Date());
        
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("aula-swing-jpaPU");
        EntityManager em = emf.createEntityManager();
        
        em.getTransaction().begin();
        em.persist(cliente);
        em.getTransaction().commit();
        em.close();
        
    }
    
}
