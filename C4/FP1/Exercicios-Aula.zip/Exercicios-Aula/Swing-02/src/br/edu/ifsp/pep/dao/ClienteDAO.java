/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifsp.pep.dao;

import br.edu.ifsp.pep.modelo.Cliente;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author cesar
 */
public class ClienteDAO {
   
    private static List<Cliente> clientes;

    public ClienteDAO() {
        if (clientes == null) {
            clientes = new ArrayList<>();
        }
    }

    public void inserir(Cliente cliente) {
        clientes.add(cliente);
        System.out.println("Cliente armazenado.");
    }
    
    public List<Cliente> buscarTodos() {
        return clientes;
    }
    
}
