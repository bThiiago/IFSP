
insert into categoria (descricao) values ("Doces");
insert into categoria (descricao) values ("Bebidas");
insert into categoria (descricao) values ("Alimentos");