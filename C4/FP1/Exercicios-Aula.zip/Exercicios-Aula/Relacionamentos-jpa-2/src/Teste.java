
import br.edu.ifsp.pep.modelo.Categoria;
import br.edu.ifsp.pep.modelo.Produto;
import br.edu.ifsp.pep.modelo.onetoone.Proprietario;
import br.edu.ifsp.pep.modelo.onetoone.Veiculo;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

public class Teste {

    private static EntityManagerFactory emf;

    public static void main(String[] args) {
        emf = Persistence.createEntityManagerFactory("jpa-relacionamentosPU");
        criarVeiculo();
        consultarVeiculo();
//        consulta();
//        criarCategoriaVinculadaProdutos();
    }

    private static void criarCategoriaVinculadaProdutos() {
        Categoria bebidas = new Categoria("Bebidas");
        List<Produto> produtos = new ArrayList();
        for (int i = 0; i < 10; i++) {
            Produto p = new Produto("Produto " + i);
            p.setCategoria(bebidas);
            produtos.add(p);
        }
        bebidas.setProdutos(produtos);

        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        em.persist(bebidas);
        em.getTransaction().commit();
        em.close();

    }

    private static void consulta() {
        EntityManager em = emf.createEntityManager();
        Categoria categoria = em.find(Categoria.class, 1);
        System.out.println(categoria);
        System.out.println("--- Lista de Produtos ---");
        for (Produto produto : categoria.getProdutos()) {
            System.out.println(produto);
        }
    }

    private static void criarCategoriaEProduto() {
        Categoria c1 = new Categoria("Alimentos");
        Produto p1 = new Produto("Arroz");
        p1.setCategoria(c1);

        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        em.persist(c1);
        em.persist(p1);
        em.getTransaction().commit();
        em.close();
    }

    private static void criarVeiculo() {
        Proprietario p1 = new Proprietario();
        p1.setNome("João");

        Veiculo v1 = new Veiculo();
        v1.setNome("Gol");
        v1.setProprietario(p1);

        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        em.persist(p1);
        em.persist(v1);
        em.getTransaction().commit();
        em.close();

    }

    private static void consultarVeiculo() {

        EntityManager em = emf.createEntityManager();
//        Veiculo veiculo = em.find(Veiculo.class, 1);
        TypedQuery<Veiculo> query = em.createQuery("SELECT v FROM Veiculo v WHERE v.codigo = :codigo", Veiculo.class);
        query.setParameter("codigo", 1);
        Veiculo veiculo = query.getSingleResult();

        System.out.println(veiculo);
    }

}
