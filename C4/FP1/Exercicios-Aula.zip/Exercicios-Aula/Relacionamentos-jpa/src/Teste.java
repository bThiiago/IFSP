
import br.edu.ifsp.pep.modelo.Categoria;
import br.edu.ifsp.pep.modelo.Produto;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Teste {

    private static EntityManagerFactory emf;

    public static void main(String[] args) {
        emf = Persistence.createEntityManagerFactory("jpa-relacionamentosPU");
//        consulta();
        criarCategoriaVinculadaProdutos();
    }

    private static void criarCategoriaVinculadaProdutos() {
        Categoria bebidas = new Categoria("Bebidas");
        List<Produto> produtos = new ArrayList();
        for (int i = 0; i < 10; i++) {
            Produto p = new Produto("Produto " + i);
            p.setCategoria(bebidas);
            produtos.add(p);
        }
        bebidas.setProdutos(produtos);

        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        em.persist(bebidas);
        em.getTransaction().commit();
        em.close();

    }

    private static void consulta() {
        EntityManager em = emf.createEntityManager();
        Categoria categoria = em.find(Categoria.class, 1);
        System.out.println(categoria);
        System.out.println("--- Lista de Produtos ---");
        for (Produto produto : categoria.getProdutos()) {
            System.out.println(produto);
        }
    }

    private static void criarCategoriaEProduto() {
        Categoria c1 = new Categoria("Alimentos");
        Produto p1 = new Produto("Arroz");
        p1.setCategoria(c1);

        EntityManager em = emf.createEntityManager();
        em.getTransaction().begin();
        em.persist(c1);
        em.persist(p1);
        em.getTransaction().commit();
        em.close();
    }

}
