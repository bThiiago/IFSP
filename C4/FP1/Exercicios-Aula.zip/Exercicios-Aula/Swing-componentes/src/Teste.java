
import br.edu.ifsp.pep.modelo.Cliente;
import java.util.Date;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author cesar
 */
public class Teste {

    public static void main(String[] args) {

        Cliente cliente = new Cliente();
//        cliente.setId(1);
        cliente.setCpf("1111");
        cliente.setEndereco("Rua qualquer 111");
        cliente.setNome("Nome da pessoa 111");
        cliente.setDataNascimento(new Date());

        EntityManagerFactory emf = Persistence.createEntityManagerFactory("componentes-swingPU");
        EntityManager em = emf.createEntityManager();

        em.getTransaction().begin();
        em.persist(cliente);
        em.getTransaction().commit();
        em.close();

    }

}
