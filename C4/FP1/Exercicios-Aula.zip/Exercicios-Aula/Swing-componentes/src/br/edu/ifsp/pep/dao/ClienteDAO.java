/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifsp.pep.dao;

import br.edu.ifsp.pep.modelo.Cliente;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

/**
 *
 * @author cesar
 */
public class ClienteDAO {

    private EntityManagerFactory emf;

    public ClienteDAO() {
        this.emf = Persistence.createEntityManagerFactory("componentes-swingPU");
    }

    public void inserir(Cliente cliente) {
        System.out.println("Cliente armazenado.");

        EntityManager em = this.emf.createEntityManager();

        em.getTransaction().begin();
        em.persist(cliente);
        em.getTransaction().commit();
        em.close();

    }

    //findAll
    public List buscarTodos() {

        EntityManager em = this.emf.createEntityManager();
        // JPQL- Java Persistence Query Language.
        TypedQuery<Cliente> query = em.createNamedQuery("cliente.buscarTodos", Cliente.class);
//        Query query = em.createQuery("select c from Cliente c");
        return query.getResultList();

    }

    // findById
    public Cliente buscarPorId(int id) {
        EntityManager em = this.emf.createEntityManager();
        TypedQuery<Cliente> query = em.createNamedQuery("cliente.buscarPorId", Cliente.class);
//        Query query = em.createQuery("select c from Cliente c where c.id = :id");
        query.setParameter("id", id);

        return (Cliente) query.getSingleResult();
    }

    public List<Cliente> buscarPorNome(String nome) {
        EntityManager em = this.emf.createEntityManager();
        TypedQuery<Cliente> query = em.createNamedQuery("cliente.buscarPorNome", Cliente.class);
//        TypedQuery<Cliente> query = em.createQuery("select c from Cliente c where c.nome LIKE :nome",
//                Cliente.class);
        query.setParameter("nome", "%" + nome + "%");

        return query.getResultList();

    }

    public List<Cliente> buscarPorCpf(String cpf) {
        EntityManager em = this.emf.createEntityManager();
        TypedQuery<Cliente> query = em.createNamedQuery("cliente.buscarPorNome", Cliente.class);
//        TypedQuery<Cliente> query = em.createQuery("SELECT c FROM Cliente c WHERE c.cpf LIKE :cpf",
//                Cliente.class);

        query.setParameter("cpf", "%" + cpf + "%");

        return query.getResultList();

    }

}
